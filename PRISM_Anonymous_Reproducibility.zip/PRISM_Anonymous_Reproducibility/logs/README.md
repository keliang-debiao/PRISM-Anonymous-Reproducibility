# Validation records

Records in this directory document source, configuration, and compact CPU
workflow checks. Every record states `evidence_status=workflow_validation`.
They are not outputs from PARA, FLICKR-AES, or LAPIS and must not be used in
manuscript tables, figures, or claims.

