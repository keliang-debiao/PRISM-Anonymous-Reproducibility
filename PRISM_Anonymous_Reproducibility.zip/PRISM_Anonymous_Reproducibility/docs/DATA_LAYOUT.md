# Data layout and contracts

The repository does not redistribute images, ratings, personal variables, or
pretrained weights. Obtain each public dataset from its original provider and
retain the provider's terms and directory structure under a private data root.

## Canonical prepared files

Each dataset adapter writes the following files under
`prepared_data/<dataset>/`:

- `images.csv`: `image_id`, `relative_path`, `sha256`, `phash`,
  `duplicate_group`, and optional public attributes;
- `users.csv`: `user_id` and available de-identified variables with explicit
  missingness indicators;
- `interactions.csv`: `user_id`, `image_id`, `rating`, and the provider's
  official partition label when available;
- `attribute_map.json`: source-variable to prespecified concept mapping;
- `dataset_manifest.json`: row counts, score limits, file hashes, adapter
  version, and preparation timestamp;
- `splits.csv`: fold and partition assignments created after duplicate control.

## Required provider metadata

PARA preparation requires the 398 development-user and 40 official-test-user
membership supplied by the established protocol. FLICKR-AES preparation
requires its official 173-user and 37-user membership. LAPIS preparation uses
all public user-image ratings and creates four user-disjoint folds.

The adapters never infer an official split by sorting identifiers. If required
provider split metadata are absent, preparation stops with a clear error.

## Attribute supervision

The learned concept vocabulary contains exactly 16 entries listed in
`configs/concepts.yaml`. Continuous, ordinal, and categorical public variables
use their respective losses. Missing labels are masked. When several source
variables map to one concept, standardized losses are averaged. Fractal
dimension remains an external descriptive variable and is not a learned query
or supervision target.

## Image processing

Images are decoded in RGB, resized with preserved aspect ratio, and padded to
448 by 448 pixels. Training does not use horizontal flipping, strong cropping,
strong color jitter, or perspective changes. Controlled robustness runs may
apply mild JPEG compression and luminance perturbation.

