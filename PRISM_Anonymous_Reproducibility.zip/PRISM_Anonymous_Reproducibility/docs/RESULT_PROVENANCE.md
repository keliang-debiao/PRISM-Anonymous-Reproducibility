# Result provenance policy

This repository uses two evidence states:

- `empirical`: produced from one of the named public datasets using a resolved
  configuration, immutable split manifest, and recorded software and hardware
  environment;
- `workflow_validation`: produced only to verify interfaces, calculations, and
  execution order.

Only `empirical` records may contribute to manuscript tables, figures,
confidence intervals, significance tests, or performance claims. The table and
figure builders validate this field before aggregation.

The manuscript-reported values under `reference_outputs/` are immutable
comparison targets. They do not change prediction files and cannot satisfy the
empirical-artifact release gate.

