# AI execution guide

This guide defines the order in which an implementation agent should execute,
inspect, and repair the repository. It must not write manuscript target values
into empirical output files. All reported results must be recomputed from
row-level predictions.

## Phase 1 environment and source checks

1. Create the environment from `environment.yml`.
2. Install the repository in editable mode.
3. Run `bash validate_package.sh`.
4. Record the CUDA, driver, GPU, Python, Torch, Transformers, PEFT, and
   bitsandbytes versions.
5. Stop if deterministic split, provenance, or boundary checks fail.

## Phase 2 public data preparation

1. Place the three public datasets under a private data root.
2. Preserve provider identifiers and official partition fields.
3. Run `prepare_dataset.py` for PARA, FLICKR-AES, and LAPIS.
4. Verify image, user, and interaction counts against the dataset configuration.
5. Compute exact and near-duplicate groups before strict image folds.
6. Confirm that fractal dimension is never assigned to a learned concept.

## Phase 3 split generation

1. Run `build_splits.py --all`.
2. Confirm PARA fold sizes 80, 80, 80, 79, and 79.
3. Confirm the frozen 40-user PARA test set is untouched during development.
4. Confirm FLICKR-AES official membership contains 173 training and 37 test users.
5. Confirm LAPIS contains four 138-user held-out folds.
6. Confirm each duplicate group belongs to one strict image fold.
7. Confirm fixed-query assignments remain byte-identical across policies and seeds.

## Phase 4 visual feature extraction

1. Load Qwen3-VL-4B-Instruct under the provider license.
2. Resize and pad each RGB image to 448 by 448 pixels without changing aspect ratio.
3. Cache blocks 5, 11, 17, and 23.
4. Hash every feature file and retain the cache manifest.
5. Reuse cached image features across acquisition policies.

## Phase 5 model training

1. Build episode shards separately for every fold.
2. Train seeds 2026, 2027, 2028, 2029, and 2030 independently.
3. Use AdamW with beta values 0.9 and 0.95, weight decay 0.01, gradient clipping
   1.0, five percent warm-up, and cosine decay.
4. Use learning rates 2e-5 for adapters, 5e-5 for experts, and 1e-4 for new modules.
5. Evaluate selection-user SROCC every 500 optimizer steps and stop after four
   evaluations without improvement.
6. Keep domain alignment disabled for standalone PARA and FLICKR-AES training.
7. During LAPIS adaptation, align only the ten shared concepts using permitted
   LAPIS training users and a frozen PARA source checkpoint.

## Phase 6 calibration and inference

1. Produce uncalibrated predictions for calibration users.
2. Fit ordinal temperature by ordinal negative log-likelihood.
3. Fit the positive variance multiplier by Gaussian negative log-likelihood.
4. Freeze both parameters before outer-test inference.
5. Aggregate all five ensemble members.
6. Form nominal 95 percent intervals in latent space, transform both limits
   through the monotonic dataset mapping, and retain both raw and bounded values.
7. Clip only after mapping: 1-5 for PARA and FLICKR-AES, 0-100 for LAPIS.

## Phase 7 controlled analyses

1. Run the fixed-query policies on the same 30 percent query interactions.
2. Run every ablation with unchanged backbone, folds, candidate pools,
   optimization budget, and seeds.
3. Run PRISM-BM with 38.7 million trainable parameters.
4. Calculate per-concept public-attribute correspondence on held-out images.
5. Calculate top-three and random-three deletion effects on the normalized scale.
6. Select case records from low-error, high-error, and high-uncertainty strata.
7. Measure cached and full latency with all five members, batch size one, 50
   warm-up iterations, and 500 measured repetitions.

## Phase 8 statistical aggregation

1. Average seed predictions within each held-out user before paired tests.
2. Calculate SROCC, PLCC, Kendall tau-b, MAE, RMSE, ordinal NLL, ECE-15,
   Brier score, Gaussian NLL, coverage, interval width, and clipping rate.
3. Use 10,000 user-cluster BCa resamples.
4. Use two-sided paired Wilcoxon signed-rank tests.
5. Apply Holm correction to the 11 prespecified comparisons.
6. Report paired rank-biserial effects.

## Phase 9 release gate

1. Run `check_release.py --require-empirical`.
2. Rebuild all numerical artifacts from empirical prediction files.
3. Compare the rebuilt outputs with `reference_outputs/manuscript_targets.json`.
4. Investigate differences beyond the declared tolerance; do not overwrite
   empirical outputs with target values.
5. Remove raw data, credentials, caches, absolute paths, and version-control
   history before creating the anonymous archive.

