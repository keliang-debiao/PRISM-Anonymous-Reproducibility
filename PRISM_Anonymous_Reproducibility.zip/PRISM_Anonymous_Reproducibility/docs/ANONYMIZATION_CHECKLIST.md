# Anonymous release checklist

- No author names, affiliations, initials, email addresses, grant identifiers,
  local home directories, host names, account names, or repository owner names.
- No version-control history or remote URL in the archive.
- No absolute local paths in configuration, logs, manifests, or checkpoints.
- Public dataset names and cited model identifiers are retained because they are
  necessary for reproducibility.
- Image and user identifiers remain dataset-scoped and contain no added personal
  information.
- Generated artifacts store hashes and relative paths only.
- Reviewer-facing archives exclude caches, credentials, authentication files,
  raw images, and provider-restricted material.

