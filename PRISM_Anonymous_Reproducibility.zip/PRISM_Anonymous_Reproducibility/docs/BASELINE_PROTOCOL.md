# Controlled baseline protocol

All controlled baselines consume the same split manifest, support budget,
image files, and score ranges. `scripts/run_baseline.py` validates a common
row-prediction contract before results enter evaluation.

Official baseline implementations remain governed by their original licenses.
Place each verified checkout outside this anonymous archive and provide a thin
local module exposing `run_baseline`. Record its immutable revision in the
corresponding provenance file. This prevents unlicensed source redistribution
while retaining exact split and output control.

PRAC uses its official mPLUG-Owl3 backbone, alpha 0.3, cohort size 6, beta 0.5,
support selection, Fisher preference embedding, user-specific LoRA, and cohort
merging. Direct Qwen3-VL plus QLoRA uses rank 16, 50 target-user gradient steps,
and the same support images as PRISM. PRISM-BM uses 38.7 million trainable
parameters with the full-model training schedule, candidate pools, support
budgets, folds, and seeds.

