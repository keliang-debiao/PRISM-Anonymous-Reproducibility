# Reviewer verification guide

## Fast checks without private storage

Run `bash validate_package.sh`. This verifies source syntax, deterministic split
logic, fixed-query invariance, acquisition-score behavior, calibration bounds,
metric calculations, provenance gating, manuscript-target structure, and
anonymous packaging.

## Full empirical verification

After obtaining the public datasets and backbone weights, use
`run_reproduction.sh` once per dataset. The script performs preparation checks,
feature extraction, five-member training, calibration, inference, evaluation,
and artifact registration. LAPIS uses the completed PARA generic-aesthetic
checkpoint and adapts only with permitted LAPIS training users.

The empirical release layout is:

```text
runs/<dataset>/<protocol>/fold_<fold>/
  episode_shards/
  checkpoints/member_<member>_seed_<seed>/
    provenance.json
    adapter_state.pt
    cohort_bank.pt
  calibration.json
  predictions.csv
  metrics/user_metrics.csv
  metrics/metrics.json
```

Every `provenance.json` must use `"evidence_status": "empirical"`, include the
dataset manifest hash, split manifest hash, source commit, command, seed,
hardware, dependency lock hash, start time, and completion time. Files marked
`workflow_validation` are rejected by manuscript table generation.

## Claim-to-artifact map

| Manuscript claim | Required command and artifact |
| --- | --- |
| Main PARA results | `run_reproduction.sh para`; five folds and five seeds |
| FLICKR-AES confirmation | `run_reproduction.sh flickr_aes`; official split |
| LAPIS transfer | `run_reproduction.sh lapis`; four user folds |
| Strict isolation | `scripts/build_splits.py --strict`; strict predictions |
| Fixed query | `scripts/run_fixed_query.py`; common query manifests and traces |
| Capacity control | `configs/prism_bm.yaml`; paired user metrics |
| Calibration | `scripts/calibrate.py`; temperature and variance multiplier |
| Per-concept evidence | `scripts/run_concept_audit.py`; concept correlations and deletions |
| Efficiency | `scripts/run_efficiency.py`; five-member timing metadata |
| Statistical inference | `scripts/evaluate.py`; clustered BCa and Holm-adjusted tests |

## Release gate

Run `python scripts/check_release.py --root . --require-empirical`. A submission
archive passes only when all expected folds, seeds, predictions, calibration
files, acquisition traces, and timing records are present and internally
consistent.

