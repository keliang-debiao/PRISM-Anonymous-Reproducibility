"""Unified command dispatch."""

from __future__ import annotations

import argparse
import subprocess
import sys


COMMANDS = {
    "prepare": "scripts/prepare_dataset.py",
    "splits": "scripts/build_splits.py",
    "features": "scripts/extract_features.py",
    "episodes": "scripts/build_episode_shards.py",
    "train": "scripts/train_ensemble.py",
    "calibrate": "scripts/calibrate.py",
    "infer": "scripts/infer.py",
    "evaluate": "scripts/evaluate.py",
    "fixed-query": "scripts/run_fixed_query.py",
    "ablation": "scripts/run_ablation.py",
    "concept-audit": "scripts/run_concept_audit.py",
    "efficiency": "scripts/run_efficiency.py",
    "baseline": "scripts/run_baseline.py",
    "reproduce": "scripts/reproduce.py",
    "check-release": "scripts/check_release.py",
}


def main() -> int:
    parser = argparse.ArgumentParser(prog="prism")
    parser.add_argument("command", choices=sorted(COMMANDS))
    arguments, remaining = parser.parse_known_args()
    return subprocess.call([sys.executable, COMMANDS[arguments.command], *remaining])


if __name__ == "__main__":
    raise SystemExit(main())

