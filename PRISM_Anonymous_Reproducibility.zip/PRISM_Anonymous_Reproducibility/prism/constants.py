"""Fixed constants defined by the manuscript protocol."""

CONCEPTS = (
    "color_harmony",
    "composition_balance",
    "subject_emphasis",
    "lighting",
    "complexity",
    "symmetry",
    "emotional_valence",
    "emotional_arousal",
    "semantic_interest",
    "technical_quality",
    "photographic_depth",
    "photographic_execution",
    "abstraction",
    "artistic_style",
    "texture_or_brushwork",
    "visual_entropy",
)

SHARED_CONCEPTS = CONCEPTS[:10]
DATASET_LIMITS = {
    "para": (1.0, 5.0),
    "flickr_aes": (1.0, 5.0),
    "lapis": (0.0, 100.0),
}
SEEDS = (2026, 2027, 2028, 2029, 2030)
ACQUISITION_WEIGHTS = {
    "controversy": 0.30,
    "personalized_deviation": 0.35,
    "concept_novelty": 0.20,
    "predictive_uncertainty": 0.15,
}
EVIDENCE_EMPIRICAL = "empirical"
EVIDENCE_WORKFLOW = "workflow_validation"

