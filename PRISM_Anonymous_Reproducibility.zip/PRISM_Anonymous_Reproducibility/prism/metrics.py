"""Per-user and aggregate performance, calibration, and interval metrics."""

from __future__ import annotations

import numpy as np
import pandas as pd
from scipy.stats import kendalltau, pearsonr, spearmanr


def expected_calibration_error(
    probabilities: np.ndarray, labels: np.ndarray, bins: int = 15
) -> float:
    probabilities = np.asarray(probabilities, dtype=float)
    labels = np.asarray(labels, dtype=int)
    confidence = probabilities.max(axis=1)
    prediction = probabilities.argmax(axis=1)
    edges = np.linspace(0.0, 1.0, bins + 1)
    value = 0.0
    for index in range(bins):
        left, right = edges[index], edges[index + 1]
        mask = (confidence > left) & (confidence <= right)
        if index == 0:
            mask |= confidence == 0.0
        if mask.any():
            accuracy = np.mean(prediction[mask] == labels[mask])
            value += mask.mean() * abs(accuracy - confidence[mask].mean())
    return float(value)


def brier_score(probabilities: np.ndarray, labels: np.ndarray) -> float:
    probabilities = np.asarray(probabilities, dtype=float)
    labels = np.asarray(labels, dtype=int)
    one_hot = np.eye(probabilities.shape[1])[labels]
    return float(np.mean(np.sum((probabilities - one_hot) ** 2, axis=1)))


def safe_correlation(function, observed: np.ndarray, predicted: np.ndarray) -> float:
    if len(observed) < 2 or np.unique(observed).size < 2 or np.unique(predicted).size < 2:
        return np.nan
    return float(function(observed, predicted).statistic)


def regression_metrics(observed: np.ndarray, predicted: np.ndarray) -> dict[str, float]:
    observed = np.asarray(observed, dtype=float)
    predicted = np.asarray(predicted, dtype=float)
    residual = observed - predicted
    return {
        "srocc": safe_correlation(spearmanr, observed, predicted),
        "plcc": safe_correlation(pearsonr, observed, predicted),
        "kendall_tau_b": safe_correlation(kendalltau, observed, predicted),
        "mae": float(np.mean(np.abs(residual))),
        "rmse": float(np.sqrt(np.mean(residual**2))),
    }


def interval_metrics(
    observed: np.ndarray, lower: np.ndarray, upper: np.ndarray
) -> dict[str, float]:
    observed = np.asarray(observed, dtype=float)
    lower = np.asarray(lower, dtype=float)
    upper = np.asarray(upper, dtype=float)
    return {
        "coverage": float(np.mean((observed >= lower) & (observed <= upper))),
        "mean_width": float(np.mean(upper - lower)),
    }


def per_user_metrics(frame: pd.DataFrame) -> pd.DataFrame:
    required = {"user_id", "observed", "predicted"}
    if missing := required - set(frame.columns):
        raise ValueError(f"Missing prediction columns: {sorted(missing)}")
    rows = []
    for user, group in frame.groupby("user_id", sort=True):
        values = regression_metrics(group["observed"].to_numpy(), group["predicted"].to_numpy())
        rows.append({"user_id": str(user), "n": len(group), **values})
    return pd.DataFrame(rows)


def aggregate_user_metrics(user_metrics: pd.DataFrame) -> dict[str, float]:
    keys = ["srocc", "plcc", "kendall_tau_b", "mae", "rmse"]
    return {key: float(user_metrics[key].mean(skipna=True)) for key in keys}

