"""Evidence-state validation for manuscript artifact generation."""

from __future__ import annotations

import json
from pathlib import Path

from prism.constants import EVIDENCE_EMPIRICAL


def read_provenance(path: str | Path) -> dict:
    return json.loads(Path(path).read_text(encoding="utf-8"))


def require_empirical(paths: list[str | Path]) -> None:
    rejected = []
    for path in paths:
        payload = read_provenance(path)
        if payload.get("evidence_status") != EVIDENCE_EMPIRICAL:
            rejected.append(str(path))
    if rejected:
        raise ValueError(
            "Manuscript artifact generation requires empirical provenance; rejected: "
            + ", ".join(rejected)
        )

