"""Randomness, hashing, provenance, and file-integrity helpers."""

from __future__ import annotations

import hashlib
import json
import os
import platform
import random
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np


def set_seed(seed: int, deterministic: bool = True) -> None:
    random.seed(seed)
    np.random.seed(seed)
    os.environ["PYTHONHASHSEED"] = str(seed)
    try:
        import torch

        torch.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
        if deterministic:
            torch.use_deterministic_algorithms(True, warn_only=True)
            torch.backends.cudnn.benchmark = False
    except ImportError:
        pass


def sha256_file(path: str | Path, chunk_size: int = 1 << 20) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        while chunk := handle.read(chunk_size):
            digest.update(chunk)
    return digest.hexdigest()


def stable_fraction(*parts: object, salt: str = "prism-fixed-query-v1") -> float:
    payload = "\x1f".join([salt, *(str(part) for part in parts)]).encode("utf-8")
    integer = int.from_bytes(hashlib.sha256(payload).digest()[:8], "big")
    return integer / float(2**64)


def source_commit() -> str:
    try:
        value = subprocess.check_output(
            ["git", "rev-parse", "HEAD"], stderr=subprocess.DEVNULL, text=True
        ).strip()
        return value
    except (subprocess.CalledProcessError, FileNotFoundError):
        return "unavailable"


def runtime_provenance(
    command: list[str],
    evidence_status: str,
    dataset_manifest_hash: str,
    split_manifest_hash: str,
    seed: int,
) -> dict[str, Any]:
    return {
        "evidence_status": evidence_status,
        "dataset_manifest_hash": dataset_manifest_hash,
        "split_manifest_hash": split_manifest_hash,
        "source_commit": source_commit(),
        "command": command,
        "seed": seed,
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "hostname_sha256": hashlib.sha256(platform.node().encode()).hexdigest(),
        "started_at_utc": datetime.now(timezone.utc).isoformat(),
    }


def write_json_atomic(path: str | Path, payload: Any) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".partial")
    temporary.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")
    temporary.replace(path)

