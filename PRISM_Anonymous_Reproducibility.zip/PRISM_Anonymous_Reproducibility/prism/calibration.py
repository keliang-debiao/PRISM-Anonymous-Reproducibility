"""Separate ordinal and continuous uncertainty calibration."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

import numpy as np
from scipy.optimize import minimize_scalar
from scipy.special import logsumexp, softmax


@dataclass(frozen=True)
class CalibrationParameters:
    temperature: float
    variance_multiplier: float


def ordinal_nll(logits: np.ndarray, labels: np.ndarray, temperature: float = 1.0) -> float:
    scaled = np.asarray(logits, dtype=float) / float(temperature)
    labels = np.asarray(labels, dtype=int)
    return float(np.mean(logsumexp(scaled, axis=1) - scaled[np.arange(len(labels)), labels]))


def fit_temperature(logits: np.ndarray, labels: np.ndarray) -> float:
    result = minimize_scalar(
        lambda value: ordinal_nll(logits, labels, value),
        bounds=(0.05, 20.0),
        method="bounded",
    )
    if not result.success:
        raise RuntimeError("Temperature optimization failed")
    return float(result.x)


def gaussian_nll(
    observed: np.ndarray,
    mean: np.ndarray,
    variance: np.ndarray,
    multiplier: float = 1.0,
) -> float:
    variance = np.maximum(np.asarray(variance, dtype=float) * multiplier, 1e-12)
    residual = np.asarray(observed, dtype=float) - np.asarray(mean, dtype=float)
    return float(np.mean(0.5 * residual**2 / variance + 0.5 * np.log(variance)))


def fit_variance_multiplier(
    observed: np.ndarray, mean: np.ndarray, variance: np.ndarray
) -> float:
    result = minimize_scalar(
        lambda log_value: gaussian_nll(observed, mean, variance, np.exp(log_value)),
        bounds=(-8.0, 8.0),
        method="bounded",
    )
    if not result.success:
        raise RuntimeError("Variance calibration optimization failed")
    return float(np.exp(result.x))


def calibrated_probabilities(logits: np.ndarray, temperature: float) -> np.ndarray:
    return softmax(np.asarray(logits, dtype=float) / temperature, axis=1)


def prediction_intervals(
    latent_mean: np.ndarray,
    latent_variance: np.ndarray,
    variance_multiplier: float,
    mapping: Callable[[np.ndarray], np.ndarray],
    score_min: float,
    score_max: float,
    z_value: float = 1.96,
) -> dict[str, np.ndarray]:
    mean = np.asarray(latent_mean, dtype=float)
    variance = np.maximum(np.asarray(latent_variance, dtype=float) * variance_multiplier, 0.0)
    radius = z_value * np.sqrt(variance)
    lower_raw = np.asarray(mapping(mean - radius), dtype=float)
    upper_raw = np.asarray(mapping(mean + radius), dtype=float)
    lower_bounded = np.clip(lower_raw, score_min, score_max)
    upper_bounded = np.clip(upper_raw, score_min, score_max)
    clipped = (lower_raw < score_min) | (upper_raw > score_max)
    return {
        "lower_raw": lower_raw,
        "upper_raw": upper_raw,
        "lower_bounded": lower_bounded,
        "upper_bounded": upper_bounded,
        "clipped": clipped,
    }

