"""Concept correspondence, deletion sensitivity, and case selection."""

from __future__ import annotations

import numpy as np
import pandas as pd
from scipy.stats import spearmanr


def concept_attribute_correlations(
    concepts: np.ndarray,
    attributes: pd.DataFrame,
    mapping: dict[int, list[str]],
) -> pd.DataFrame:
    concepts = np.asarray(concepts, dtype=float)
    rows = []
    for concept_index, columns in sorted(mapping.items()):
        eligible = [column for column in columns if column in attributes]
        correlations = []
        for column in eligible:
            values = attributes[column].to_numpy(dtype=float)
            mask = np.isfinite(values) & np.isfinite(concepts[:, concept_index])
            if mask.sum() >= 3 and np.unique(values[mask]).size >= 2:
                correlations.append(float(spearmanr(concepts[mask, concept_index], values[mask]).statistic))
        rows.append(
            {
                "concept_index": concept_index,
                "eligible_attributes": "|".join(eligible),
                "srocc": float(np.mean(correlations)) if correlations else np.nan,
            }
        )
    return pd.DataFrame(rows)


def deletion_effect(original: np.ndarray, deleted: np.ndarray) -> float:
    return float(np.mean(np.abs(np.asarray(original) - np.asarray(deleted))))


def select_case_strata(frame: pd.DataFrame, per_dataset: int = 4) -> pd.DataFrame:
    required = {"dataset", "user_id", "image_id", "observed", "predicted", "interval_width"}
    if missing := required - set(frame.columns):
        raise ValueError(f"Missing case columns: {sorted(missing)}")
    frame = frame.copy()
    frame["absolute_error"] = (frame["observed"] - frame["predicted"]).abs()
    selected = []
    for dataset, group in frame.groupby("dataset", sort=True):
        low = group.nsmallest(2, ["absolute_error", "image_id"])
        high = group.nlargest(1, ["absolute_error", "image_id"])
        uncertain = group.drop(index=low.index.union(high.index)).nlargest(
            1, ["interval_width", "image_id"]
        )
        block = pd.concat([low, high, uncertain]).head(per_dataset).copy()
        block["case_stratum"] = ["low_error", "low_error", "high_error", "high_uncertainty"][
            : len(block)
        ]
        selected.append(block)
    return pd.concat(selected, ignore_index=True)

