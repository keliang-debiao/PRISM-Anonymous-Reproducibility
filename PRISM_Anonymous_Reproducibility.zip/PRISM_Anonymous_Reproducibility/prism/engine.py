"""Training, checkpointing, calibration handoff, and row prediction writing."""

from __future__ import annotations

import csv
import json
from dataclasses import asdict
from pathlib import Path
from typing import Iterable

import torch
from torch.nn import functional as F

from prism.losses import total_loss
from prism.utils.reproducibility import write_json_atomic


class EarlyStopping:
    def __init__(self, patience: int = 4) -> None:
        self.patience = patience
        self.best = float("-inf")
        self.stale = 0

    def update(self, value: float) -> bool:
        if value > self.best:
            self.best = value
            self.stale = 0
            return False
        self.stale += 1
        return self.stale >= self.patience


def parameter_groups(model: torch.nn.Module, learning_rates: dict[str, float]):
    groups = {"adapter": [], "expert": [], "new_modules": []}
    for name, parameter in model.named_parameters():
        if not parameter.requires_grad:
            continue
        if "expert" in name:
            groups["expert"].append(parameter)
        elif "lora" in name or "adapter" in name:
            groups["adapter"].append(parameter)
        else:
            groups["new_modules"].append(parameter)
    return [
        {"params": parameters, "lr": learning_rates[key], "group_name": key}
        for key, parameters in groups.items()
        if parameters
    ]


def save_checkpoint(
    path: str | Path,
    model: torch.nn.Module,
    optimizer: torch.optim.Optimizer,
    epoch: int,
    step: int,
    metadata: dict,
) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    torch.save(
        {
            "model": model.state_dict(),
            "optimizer": optimizer.state_dict(),
            "epoch": epoch,
            "step": step,
            "metadata": metadata,
        },
        path,
    )


def write_prediction_rows(path: str | Path, rows: Iterable[dict]) -> None:
    rows = list(rows)
    if not rows:
        raise ValueError("No prediction rows were supplied")
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fields = list(rows[0])
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            serialized = {
                key: json.dumps(value) if isinstance(value, (list, tuple, dict)) else value
                for key, value in row.items()
            }
            writer.writerow(serialized)


def train_one_epoch(model, loader, optimizer, scheduler, device, domain_enabled: bool):
    model.train()
    running = 0.0
    for batch in loader:
        optimizer.zero_grad(set_to_none=True)
        output = model(**batch["model_inputs"])
        components = batch["loss_components"](output, domain_enabled=domain_enabled)
        loss = total_loss(**components)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        optimizer.step()
        if scheduler is not None:
            scheduler.step()
        running += float(loss.detach().cpu())
    return running / max(1, len(loader))

