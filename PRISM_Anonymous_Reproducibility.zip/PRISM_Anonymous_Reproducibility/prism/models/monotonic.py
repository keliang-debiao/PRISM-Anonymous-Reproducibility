"""Dataset-specific positive-increment piecewise-linear mappings."""

from __future__ import annotations

import torch
from torch import nn
from torch.nn import functional as F


class MonotonicPiecewiseLinear(nn.Module):
    def __init__(self, knots: int, output_min: float, output_max: float) -> None:
        super().__init__()
        if knots < 2:
            raise ValueError("At least two knots are required")
        self.knots = knots
        self.output_min = float(output_min)
        self.output_max = float(output_max)
        self.raw_increments = nn.Parameter(torch.zeros(knots - 1))

    def knot_values(self) -> torch.Tensor:
        increments = F.softplus(self.raw_increments) + 1e-6
        cumulative = torch.cat([increments.new_zeros(1), increments.cumsum(dim=0)])
        normalized = cumulative / cumulative[-1]
        return self.output_min + normalized * (self.output_max - self.output_min)

    def forward(self, latent: torch.Tensor) -> torch.Tensor:
        position = torch.sigmoid(latent) * (self.knots - 1)
        left = torch.floor(position).long().clamp(0, self.knots - 2)
        right = left + 1
        fraction = position - left.to(position.dtype)
        values = self.knot_values()
        return values[left] * (1.0 - fraction) + values[right] * fraction

