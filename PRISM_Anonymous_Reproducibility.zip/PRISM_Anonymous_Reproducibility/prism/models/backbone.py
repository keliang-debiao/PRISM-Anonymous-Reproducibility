"""Qwen3-VL multilevel feature extraction and cache writing."""

from __future__ import annotations

from contextlib import ExitStack
from pathlib import Path

import numpy as np
from PIL import Image


class Qwen3VLFeatureExtractor:
    def __init__(
        self,
        model_name: str = "Qwen/Qwen3-VL-4B-Instruct",
        layers: tuple[int, ...] = (5, 11, 17, 23),
        device_map: str = "auto",
        load_in_4bit: bool = True,
    ) -> None:
        import torch
        from transformers import AutoModelForImageTextToText, AutoProcessor, BitsAndBytesConfig

        self.torch = torch
        self.layers = layers
        quantization = None
        if load_in_4bit:
            quantization = BitsAndBytesConfig(
                load_in_4bit=True,
                bnb_4bit_compute_dtype=torch.bfloat16,
                bnb_4bit_quant_type="nf4",
                bnb_4bit_use_double_quant=True,
            )
        self.processor = AutoProcessor.from_pretrained(model_name, trust_remote_code=True)
        self.model = AutoModelForImageTextToText.from_pretrained(
            model_name,
            device_map=device_map,
            quantization_config=quantization,
            torch_dtype=torch.bfloat16,
            trust_remote_code=True,
        ).eval()
        self.visual_blocks = self._resolve_visual_blocks()

    def _resolve_visual_blocks(self):
        candidates = [
            ("visual", "blocks"),
            ("model", "visual", "blocks"),
            ("vision_tower", "blocks"),
        ]
        for path in candidates:
            current = self.model
            for name in path:
                current = getattr(current, name, None)
                if current is None:
                    break
            if current is not None:
                return current
        raise RuntimeError("Unable to locate Qwen3-VL visual transformer blocks")

    def extract(self, image_path: str | Path) -> list[np.ndarray]:
        captured: dict[int, object] = {}
        with Image.open(image_path) as image:
            rgb = image.convert("RGB")
            scale = min(448 / rgb.width, 448 / rgb.height)
            resized = rgb.resize(
                (max(1, round(rgb.width * scale)), max(1, round(rgb.height * scale))),
                Image.Resampling.BICUBIC,
            )
            canvas = Image.new("RGB", (448, 448), color=(127, 127, 127))
            canvas.paste(
                resized,
                ((448 - resized.width) // 2, (448 - resized.height) // 2),
            )
            rgb = canvas
            messages = [{"role": "user", "content": [{"type": "image", "image": rgb}]}]
            text = self.processor.apply_chat_template(
                messages, tokenize=False, add_generation_prompt=False
            )
            inputs = self.processor(text=[text], images=[rgb], return_tensors="pt")
        model_device = next(self.model.parameters()).device
        inputs = {key: value.to(model_device) for key, value in inputs.items()}

        def capture(index):
            def hook(_module, _inputs, output):
                value = output[0] if isinstance(output, tuple) else output
                captured[index] = value.detach().float().cpu()

            return hook

        with ExitStack() as stack:
            for index in self.layers:
                stack.callback(self.visual_blocks[index].register_forward_hook(capture(index)).remove)
            with self.torch.no_grad():
                self.model(**inputs, output_hidden_states=False, use_cache=False)
        return [captured[index].squeeze(0).numpy() for index in self.layers]


def save_feature_record(path: str | Path, image_id: str, features: list[np.ndarray]) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(path, image_id=np.asarray(image_id), **{f"layer_{i}": value for i, value in enumerate(features)})

