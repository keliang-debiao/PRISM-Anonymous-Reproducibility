"""End-to-end PRISM member and five-member ensemble."""

from __future__ import annotations

from dataclasses import dataclass

import torch
from torch import nn
from torch.nn import functional as F

from prism.models.components import (
    CohortGraph,
    ConceptResidual,
    MultiLevelProjector,
    SparseExpertMixture,
    SupportSetEncoder,
)
from prism.models.monotonic import MonotonicPiecewiseLinear


@dataclass
class MemberOutput:
    latent_score: torch.Tensor
    native_mean: torch.Tensor
    aleatoric_variance: torch.Tensor
    ordinal_logits: torch.Tensor
    concepts: torch.Tensor
    concept_sensitivities: torch.Tensor
    routing_weights: torch.Tensor
    generic_score: torch.Tensor
    bounded_residual: torch.Tensor
    preference_embedding: torch.Tensor
    cohort_embedding: torch.Tensor


class PRISMMember(nn.Module):
    def __init__(
        self,
        visual_dim: int,
        support_token_dim: int,
        profile_dim: int,
        score_min: float,
        score_max: float,
        hidden_dim: int = 512,
        experts: int = 8,
    ) -> None:
        super().__init__()
        self.visual = MultiLevelProjector(visual_dim, hidden_dim)
        self.concept_residual = ConceptResidual(hidden_dim)
        self.user_encoder = SupportSetEncoder(support_token_dim, profile_dim, hidden_dim)
        self.cohort_graph = CohortGraph(hidden_dim)
        self.expert_mixture = SparseExpertMixture(hidden_dim, experts=experts, active=2, rank=8)
        self.expert_scalar = nn.Linear(hidden_dim, 1)
        self.personal_residual = nn.Sequential(
            nn.Linear(hidden_dim * 2, hidden_dim), nn.GELU(), nn.Linear(hidden_dim, 1)
        )
        self.personal_gate = nn.Parameter(torch.ones(()))
        self.variance_head = nn.Sequential(
            nn.Linear(hidden_dim * 2, hidden_dim // 2), nn.GELU(), nn.Linear(hidden_dim // 2, 1)
        )
        self.ordinal_head = nn.Linear(1, 5)
        self.scale_mapping = MonotonicPiecewiseLinear(9, score_min, score_max)

    def forward(
        self,
        visual_levels: list[torch.Tensor],
        support_tokens: torch.Tensor | None,
        profile: torch.Tensor,
        cohort_preference: torch.Tensor,
        cohort_sensitivity: torch.Tensor,
        support_agreement: torch.Tensor | None = None,
        support_visual_levels: list[torch.Tensor] | None = None,
        support_ratings_normalized: torch.Tensor | None = None,
    ) -> MemberOutput:
        image_hidden, visual_tokens = self.visual(visual_levels)
        concepts, generic, bounded = self.concept_residual(image_hidden, visual_tokens)
        if (
            support_tokens is None
            and support_visual_levels is not None
            and support_visual_levels[0].shape[1] > 0
        ):
            if support_ratings_normalized is None:
                raise ValueError("Normalized support ratings are required with support visual features")
            batch, support_count = support_visual_levels[0].shape[:2]
            flattened_levels = [
                level.reshape(batch * support_count, *level.shape[2:])
                for level in support_visual_levels
            ]
            support_hidden, support_visual_tokens = self.visual(flattened_levels)
            support_concepts, support_generic, _ = self.concept_residual(
                support_hidden, support_visual_tokens
            )
            support_hidden = support_hidden.reshape(batch, support_count, -1)
            support_concepts = support_concepts.reshape(batch, support_count, -1)
            support_generic = torch.sigmoid(support_generic.reshape(batch, support_count, 1))
            support_ratings = support_ratings_normalized.reshape(batch, support_count, 1)
            support_tokens = torch.cat(
                [
                    support_concepts,
                    support_ratings,
                    support_ratings - support_generic,
                    support_hidden,
                ],
                dim=-1,
            )
        preference, sensitivity = self.user_encoder(support_tokens, profile)
        cohort, _, _ = self.cohort_graph(
            preference,
            sensitivity,
            cohort_preference,
            cohort_sensitivity,
            support_agreement,
        )
        update, routing = self.expert_mixture(image_hidden, preference, cohort)
        personalized_residual = 0.20 * torch.tanh(
            self.personal_gate * self.personal_residual(torch.cat([preference, image_hidden], dim=-1))
        ).squeeze(-1)
        latent = (
            generic
            + (sensitivity * concepts).sum(dim=-1)
            + self.expert_scalar(update).squeeze(-1)
            + personalized_residual
        )
        native_mean = self.scale_mapping(latent)
        variance = F.softplus(self.variance_head(torch.cat([preference, image_hidden], dim=-1))).squeeze(-1) + 1e-6
        ordinal_logits = self.ordinal_head(latent[:, None])
        return MemberOutput(
            latent,
            native_mean,
            variance,
            ordinal_logits,
            concepts,
            sensitivity,
            routing,
            generic,
            bounded,
            preference,
            cohort,
        )


class PRISMEnsemble(nn.Module):
    def __init__(self, members: list[PRISMMember]) -> None:
        super().__init__()
        if len(members) != 5:
            raise ValueError("PRISM uncertainty aggregation requires five members")
        self.members = nn.ModuleList(members)

    def forward(self, **kwargs) -> dict[str, torch.Tensor | list[MemberOutput]]:
        outputs = [member(**kwargs) for member in self.members]
        means = torch.stack([output.native_mean for output in outputs], dim=0)
        variances = torch.stack([output.aleatoric_variance for output in outputs], dim=0)
        ensemble_mean = means.mean(dim=0)
        total_variance = (variances + means.square()).mean(dim=0) - ensemble_mean.square()
        ordinal = torch.stack([output.ordinal_logits for output in outputs], dim=0).mean(dim=0)
        return {
            "member_outputs": outputs,
            "mean": ensemble_mean,
            "total_variance": total_variance.clamp_min(1e-8),
            "member_means": means,
            "member_variances": variances,
            "member_latent_scores": torch.stack(
                [output.latent_score for output in outputs], dim=0
            ),
            "ordinal_logits": ordinal,
            "concepts": torch.stack([output.concepts for output in outputs], dim=0).mean(dim=0),
            "concept_sensitivities": torch.stack(
                [output.concept_sensitivities for output in outputs], dim=0
            ).mean(dim=0),
            "routing_weights": torch.stack(
                [output.routing_weights for output in outputs], dim=0
            ).mean(dim=0),
            "bounded_residual": torch.stack(
                [output.bounded_residual for output in outputs], dim=0
            ).mean(dim=0),
            "preference_embedding": torch.stack(
                [output.preference_embedding for output in outputs], dim=0
            ).mean(dim=0),
            "cohort_embedding": torch.stack(
                [output.cohort_embedding for output in outputs], dim=0
            ).mean(dim=0),
        }

