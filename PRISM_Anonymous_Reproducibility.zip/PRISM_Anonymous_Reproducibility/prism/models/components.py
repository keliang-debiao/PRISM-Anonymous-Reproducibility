"""Neural components for multilevel concepts, user sets, cohorts, and experts."""

from __future__ import annotations

import torch
from torch import nn
from torch.nn import functional as F


class MultiLevelProjector(nn.Module):
    def __init__(self, input_dim: int, hidden_dim: int = 512, levels: int = 4) -> None:
        super().__init__()
        self.projections = nn.ModuleList([nn.Linear(input_dim, hidden_dim) for _ in range(levels)])
        self.pool_query = nn.Parameter(torch.randn(1, 1, hidden_dim) * 0.02)
        self.pool = nn.MultiheadAttention(hidden_dim, 8, batch_first=True)
        self.norm = nn.LayerNorm(hidden_dim)

    def forward(self, level_tokens: list[torch.Tensor]) -> tuple[torch.Tensor, torch.Tensor]:
        if len(level_tokens) != len(self.projections):
            raise ValueError("Unexpected number of visual feature levels")
        tokens = torch.cat(
            [projection(features) for projection, features in zip(self.projections, level_tokens)],
            dim=1,
        )
        query = self.pool_query.expand(tokens.shape[0], -1, -1)
        pooled, _ = self.pool(query, tokens, tokens, need_weights=False)
        return self.norm(pooled[:, 0]), tokens


class ConceptResidual(nn.Module):
    def __init__(self, hidden_dim: int = 512, concepts: int = 16, heads: int = 4) -> None:
        super().__init__()
        self.query = nn.Parameter(torch.randn(concepts, hidden_dim) * 0.02)
        self.cross_attention = nn.MultiheadAttention(hidden_dim, heads, batch_first=True)
        self.scalar = nn.Sequential(nn.LayerNorm(hidden_dim), nn.Linear(hidden_dim, 1))
        self.population_weights = nn.Parameter(torch.zeros(concepts))
        self.residual = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim), nn.GELU(), nn.Linear(hidden_dim, 1)
        )
        self.residual_bound = 0.25

    def forward(
        self, pooled_image: torch.Tensor, visual_tokens: torch.Tensor
    ) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        queries = self.query.unsqueeze(0).expand(visual_tokens.shape[0], -1, -1)
        concept_tokens, _ = self.cross_attention(
            queries, visual_tokens, visual_tokens, need_weights=False
        )
        concepts = self.scalar(concept_tokens).squeeze(-1)
        bounded_residual = self.residual_bound * torch.tanh(self.residual(pooled_image)).squeeze(-1)
        generic_score = concepts @ self.population_weights + bounded_residual
        return concepts, generic_score, bounded_residual


class MultiheadAttentionBlock(nn.Module):
    def __init__(self, hidden_dim: int, heads: int) -> None:
        super().__init__()
        self.attention = nn.MultiheadAttention(hidden_dim, heads, batch_first=True)
        self.norm1 = nn.LayerNorm(hidden_dim)
        self.feed_forward = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim * 2),
            nn.GELU(),
            nn.Linear(hidden_dim * 2, hidden_dim),
        )
        self.norm2 = nn.LayerNorm(hidden_dim)

    def forward(self, query: torch.Tensor, key_value: torch.Tensor) -> torch.Tensor:
        attended, _ = self.attention(query, key_value, key_value, need_weights=False)
        hidden = self.norm1(query + attended)
        return self.norm2(hidden + self.feed_forward(hidden))


class InducedSetAttentionBlock(nn.Module):
    def __init__(self, hidden_dim: int, heads: int, inducing_points: int) -> None:
        super().__init__()
        self.inducing = nn.Parameter(torch.randn(1, inducing_points, hidden_dim) * 0.02)
        self.to_inducing = MultiheadAttentionBlock(hidden_dim, heads)
        self.to_elements = MultiheadAttentionBlock(hidden_dim, heads)

    def forward(self, elements: torch.Tensor) -> torch.Tensor:
        inducing = self.inducing.expand(elements.shape[0], -1, -1)
        summary = self.to_inducing(inducing, elements)
        return self.to_elements(elements, summary)


class SupportSetEncoder(nn.Module):
    def __init__(
        self,
        token_dim: int,
        profile_dim: int,
        hidden_dim: int = 512,
        heads: int = 8,
        inducing_points: int = 16,
    ) -> None:
        super().__init__()
        self.token_projection = nn.Linear(token_dim + profile_dim, hidden_dim)
        self.block1 = InducedSetAttentionBlock(hidden_dim, heads, inducing_points)
        self.block2 = InducedSetAttentionBlock(hidden_dim, heads, inducing_points)
        self.pool_seed = nn.Parameter(torch.randn(1, 1, hidden_dim) * 0.02)
        self.pool = MultiheadAttentionBlock(hidden_dim, heads)
        self.cold_token = nn.Parameter(torch.randn(1, hidden_dim) * 0.02)
        self.cold_projection = nn.Sequential(
            nn.Linear(hidden_dim + profile_dim, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, hidden_dim),
        )
        self.sensitivity = nn.Linear(hidden_dim, 16)

    def forward(
        self,
        support_tokens: torch.Tensor | None,
        profile: torch.Tensor,
        support_mask: torch.Tensor | None = None,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        if support_tokens is None or support_tokens.shape[1] == 0:
            cold = self.cold_token.expand(profile.shape[0], -1)
            preference = self.cold_projection(torch.cat([cold, profile], dim=-1))
        else:
            profile_expanded = profile[:, None, :].expand(-1, support_tokens.shape[1], -1)
            elements = self.token_projection(torch.cat([support_tokens, profile_expanded], dim=-1))
            if support_mask is not None:
                elements = elements * support_mask.unsqueeze(-1)
            elements = self.block2(self.block1(elements))
            seed = self.pool_seed.expand(elements.shape[0], -1, -1)
            preference = self.pool(seed, elements)[:, 0]
        return preference, torch.tanh(self.sensitivity(preference))


class CohortGraph(nn.Module):
    def __init__(self, hidden_dim: int = 512, max_neighbors: int = 8) -> None:
        super().__init__()
        self.max_neighbors = max_neighbors
        self.transform = nn.Linear(hidden_dim, hidden_dim, bias=False)
        self.attention = nn.Sequential(
            nn.Linear(hidden_dim * 2 + 1, hidden_dim // 2),
            nn.LeakyReLU(0.2),
            nn.Linear(hidden_dim // 2, 1),
        )

    def forward(
        self,
        target_preference: torch.Tensor,
        target_sensitivity: torch.Tensor,
        cohort_preference: torch.Tensor,
        cohort_sensitivity: torch.Tensor,
        support_agreement: torch.Tensor | None = None,
    ) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        preference_similarity = F.cosine_similarity(
            target_preference[:, None, :], cohort_preference[None, :, :], dim=-1
        )
        sensitivity_similarity = F.cosine_similarity(
            target_sensitivity[:, None, :], cohort_sensitivity[None, :, :], dim=-1
        )
        if support_agreement is None:
            support_agreement = torch.zeros_like(preference_similarity)
        initial = (
            0.55 * preference_similarity
            + 0.25 * sensitivity_similarity
            + 0.20 * support_agreement
        )
        neighbor_count = min(self.max_neighbors, cohort_preference.shape[0])
        scores, indices = initial.topk(neighbor_count, dim=1)
        neighbors = cohort_preference[indices]
        target = target_preference[:, None, :].expand_as(neighbors)
        logits = self.attention(torch.cat([self.transform(target), self.transform(neighbors), scores[..., None]], dim=-1)).squeeze(-1)
        weights = torch.softmax(logits, dim=1)
        enhanced = torch.sigmoid((weights[..., None] * self.transform(neighbors)).sum(dim=1))
        return enhanced, weights, indices


class LowRankExpert(nn.Module):
    def __init__(self, hidden_dim: int, rank: int = 8) -> None:
        super().__init__()
        self.down = nn.Linear(hidden_dim, rank, bias=False)
        self.up = nn.Linear(rank, hidden_dim, bias=False)
        nn.init.zeros_(self.up.weight)

    def forward(self, hidden: torch.Tensor) -> torch.Tensor:
        return self.up(self.down(hidden))


class SparseExpertMixture(nn.Module):
    def __init__(self, hidden_dim: int = 512, experts: int = 8, active: int = 2, rank: int = 8) -> None:
        super().__init__()
        self.experts = nn.ModuleList([LowRankExpert(hidden_dim, rank) for _ in range(experts)])
        self.router = nn.Linear(hidden_dim * 2, experts)
        self.active = active

    def forward(
        self, image_hidden: torch.Tensor, preference: torch.Tensor, cohort: torch.Tensor
    ) -> tuple[torch.Tensor, torch.Tensor]:
        logits = self.router(torch.cat([preference, cohort], dim=-1))
        top_values, top_indices = logits.topk(self.active, dim=-1)
        top_weights = torch.softmax(top_values, dim=-1)
        routing = torch.zeros_like(logits).scatter(1, top_indices, top_weights)
        updates = torch.stack([expert(image_hidden) for expert in self.experts], dim=1)
        update = (updates * routing[:, :, None]).sum(dim=1)
        return update, routing

