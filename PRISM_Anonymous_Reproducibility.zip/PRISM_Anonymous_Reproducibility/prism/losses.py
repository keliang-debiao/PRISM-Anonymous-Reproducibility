"""PRISM objectives corresponding to manuscript equations 25-32."""

from __future__ import annotations

import torch
from torch.nn import functional as F


def heteroscedastic_score_loss(
    observed: torch.Tensor, means: torch.Tensor, variances: torch.Tensor
) -> torch.Tensor:
    variances = variances.clamp_min(1e-6)
    return (0.5 * (observed[None, :] - means).square() / variances + 0.5 * variances.log()).mean()


def pairwise_rank_loss(
    latent_scores: torch.Tensor, observed: torch.Tensor, pair_indices: torch.Tensor
) -> torch.Tensor:
    left, right = pair_indices[:, 0], pair_indices[:, 1]
    target = (observed[left] > observed[right]).float()
    return F.binary_cross_entropy_with_logits(latent_scores[left] - latent_scores[right], target)


def masked_attribute_loss(
    predictions: torch.Tensor,
    targets: torch.Tensor,
    mask: torch.Tensor,
) -> torch.Tensor:
    valid = mask.bool()
    if valid.sum() == 0:
        return predictions.new_zeros(())
    return F.smooth_l1_loss(predictions[valid], targets[valid])


def cohort_contrastive_loss(
    embeddings: torch.Tensor,
    positive_mask: torch.Tensor,
    temperature: float = 0.10,
) -> torch.Tensor:
    normalized = F.normalize(embeddings, dim=-1)
    logits = normalized @ normalized.T / temperature
    identity = torch.eye(len(embeddings), dtype=torch.bool, device=embeddings.device)
    logits = logits.masked_fill(identity, float("-inf"))
    denominator = torch.logsumexp(logits, dim=1)
    numerator = torch.logsumexp(logits.masked_fill(~positive_mask.bool(), float("-inf")), dim=1)
    valid = positive_mask.sum(dim=1) > 0
    return -(numerator[valid] - denominator[valid]).mean()


def deep_coral_loss(source: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
    if source.shape[1] != 10 or target.shape[1] != 10:
        raise ValueError("Domain alignment is restricted to ten shared concepts")
    source_centered = source - source.mean(dim=0, keepdim=True)
    target_centered = target - target.mean(dim=0, keepdim=True)
    source_cov = source_centered.T @ source_centered / max(1, source.shape[0] - 1)
    target_cov = target_centered.T @ target_centered / max(1, target.shape[0] - 1)
    return (source_cov - target_cov).square().sum() / (4.0 * 10**2)


def regularization_loss(
    residual: torch.Tensor,
    routing_weights: torch.Tensor,
    concept_queries: torch.Tensor,
) -> torch.Tensor:
    residual_term = 0.01 * residual.square().mean()
    entropy = -(routing_weights.clamp_min(1e-12) * routing_weights.clamp_min(1e-12).log()).sum(dim=-1)
    routing_term = 0.005 * entropy.mean()
    normalized_queries = F.normalize(concept_queries, dim=-1)
    gram = normalized_queries @ normalized_queries.T
    identity = torch.eye(gram.shape[0], device=gram.device)
    concept_term = 0.01 * (gram - identity).square().sum()
    return residual_term + routing_term + concept_term


def total_loss(
    score: torch.Tensor,
    rank: torch.Tensor,
    attribute: torch.Tensor,
    cohort: torch.Tensor,
    domain: torch.Tensor,
    ordinal: torch.Tensor,
    regularization: torch.Tensor,
) -> torch.Tensor:
    return (
        score
        + 0.40 * rank
        + 0.15 * attribute
        + 0.10 * cohort
        + 0.05 * domain
        + 0.20 * ordinal
        + regularization
    )

