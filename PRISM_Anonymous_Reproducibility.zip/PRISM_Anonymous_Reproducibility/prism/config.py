"""Configuration loading with deterministic inheritance and validation."""

from __future__ import annotations

from copy import deepcopy
from pathlib import Path
from typing import Any

import yaml


def _deep_merge(base: dict[str, Any], override: dict[str, Any]) -> dict[str, Any]:
    merged = deepcopy(base)
    for key, value in override.items():
        if key == "defaults":
            continue
        if isinstance(value, dict) and isinstance(merged.get(key), dict):
            merged[key] = _deep_merge(merged[key], value)
        else:
            merged[key] = deepcopy(value)
    return merged


def load_config(path: str | Path) -> dict[str, Any]:
    """Load YAML and resolve one or more relative default files."""
    path = Path(path).resolve()
    with path.open("r", encoding="utf-8") as handle:
        current = yaml.safe_load(handle) or {}
    defaults = current.get("defaults")
    if not defaults:
        resolved = current
    else:
        names = [defaults] if isinstance(defaults, str) else list(defaults)
        resolved: dict[str, Any] = {}
        for name in names:
            resolved = _deep_merge(resolved, load_config(path.parent / name))
        resolved = _deep_merge(resolved, current)
    validate_config(resolved)
    return resolved


def validate_config(config: dict[str, Any]) -> None:
    """Fail early when a resolved configuration violates manuscript invariants."""
    model = config.get("model", {})
    if model:
        if model.get("concepts") != 16:
            raise ValueError("The learned concept vocabulary must contain 16 entries")
        if model.get("active_experts") != 2:
            raise ValueError("PRISM activates exactly two experts")
        if model.get("ensemble_members") != 5:
            raise ValueError("Uncertainty requires five independent members")
        if model.get("feature_layers") != [5, 11, 17, 23]:
            raise ValueError("Visual feature layers must be 5, 11, 17, and 23")
    acquisition = config.get("acquisition", {})
    if acquisition:
        weights = acquisition.get("weights", {})
        if abs(sum(float(v) for v in weights.values()) - 1.0) > 1e-12:
            raise ValueError("Acquisition weights must sum to one")
    dataset = config.get("dataset", {})
    alignment = config.get("domain_alignment", {})
    if dataset.get("name") in {"para", "flickr_aes"} and alignment.get("enabled"):
        raise ValueError("Domain alignment is inactive for standalone photographic training")

