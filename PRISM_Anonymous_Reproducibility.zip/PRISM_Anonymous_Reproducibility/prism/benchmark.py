"""Latency benchmarking with explicit operation and ensemble scope."""

from __future__ import annotations

import statistics
import time
from dataclasses import dataclass, asdict
from typing import Callable


@dataclass
class TimingSummary:
    repetitions: int
    warmup: int
    median_ms: float
    p95_ms: float
    includes_all_ensemble_members: bool
    includes_visual_encoding: bool
    candidate_pool: int | None
    support_budget: int | None


def benchmark_callable(
    operation: Callable[[], object],
    repetitions: int = 500,
    warmup: int = 50,
    includes_visual_encoding: bool = False,
    candidate_pool: int | None = None,
    support_budget: int | None = None,
) -> TimingSummary:
    try:
        import torch

        synchronize = torch.cuda.synchronize if torch.cuda.is_available() else lambda: None
    except ImportError:
        synchronize = lambda: None
    for _ in range(warmup):
        operation()
    durations = []
    for _ in range(repetitions):
        synchronize()
        start = time.perf_counter()
        operation()
        synchronize()
        durations.append((time.perf_counter() - start) * 1000.0)
    ordered = sorted(durations)
    p95_index = min(len(ordered) - 1, int(round(0.95 * (len(ordered) - 1))))
    return TimingSummary(
        repetitions,
        warmup,
        statistics.median(durations),
        ordered[p95_index],
        True,
        includes_visual_encoding,
        candidate_pool,
        support_budget,
    )

