"""Preference-rich uncertainty-aware sequential acquisition."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

import numpy as np

from prism.constants import ACQUISITION_WEIGHTS


def _normalize_rows(probabilities: np.ndarray) -> np.ndarray:
    probabilities = np.asarray(probabilities, dtype=float)
    probabilities = np.clip(probabilities, 1e-12, None)
    return probabilities / probabilities.sum(axis=-1, keepdims=True)


def controversy(population_probabilities: np.ndarray) -> np.ndarray:
    probabilities = _normalize_rows(population_probabilities)
    return -(probabilities * np.log(probabilities + 1e-8)).sum(axis=-1)


def personalized_deviation(
    user_probabilities: np.ndarray, population_probabilities: np.ndarray
) -> np.ndarray:
    user = _normalize_rows(user_probabilities)
    population = _normalize_rows(population_probabilities)
    return (user * (np.log(user + 1e-12) - np.log(population + 1e-12))).sum(axis=-1)


def concept_novelty(
    candidate_concepts: np.ndarray,
    support_concepts: np.ndarray | None,
    training_centroid: np.ndarray,
) -> np.ndarray:
    candidate = np.asarray(candidate_concepts, dtype=float)
    if support_concepts is None or len(support_concepts) == 0:
        return np.linalg.norm(candidate - training_centroid[None, :], axis=1)
    distances = np.linalg.norm(candidate[:, None, :] - support_concepts[None, :, :], axis=-1)
    return distances.min(axis=1)


def zscore(values: np.ndarray) -> np.ndarray:
    values = np.asarray(values, dtype=float)
    deviation = values.std(ddof=0)
    if deviation < 1e-12:
        return np.zeros_like(values)
    return (values - values.mean()) / deviation


def acquisition_score(
    population_probabilities: np.ndarray,
    user_probabilities: np.ndarray,
    candidate_concepts: np.ndarray,
    support_concepts: np.ndarray | None,
    training_centroid: np.ndarray,
    predictive_uncertainty: np.ndarray,
    first_step: bool = False,
    weights: dict[str, float] | None = None,
) -> tuple[np.ndarray, dict[str, np.ndarray]]:
    weights = weights or ACQUISITION_WEIGHTS
    terms = {
        "controversy": controversy(population_probabilities),
        "personalized_deviation": (
            np.zeros(len(population_probabilities))
            if first_step
            else personalized_deviation(user_probabilities, population_probabilities)
        ),
        "concept_novelty": concept_novelty(
            candidate_concepts, support_concepts, training_centroid
        ),
        "predictive_uncertainty": np.asarray(predictive_uncertainty, dtype=float),
    }
    standardized = {name: zscore(values) for name, values in terms.items()}
    score = sum(weights[name] * standardized[name] for name in weights)
    return np.asarray(score), standardized


@dataclass
class AcquisitionStep:
    step: int
    selected_index: int
    selected_score: float


def sequential_select(
    candidate_count: int,
    support_budget: int,
    scorer: Callable[[list[int], np.ndarray], np.ndarray],
) -> list[AcquisitionStep]:
    if support_budget > candidate_count:
        raise ValueError("Support budget exceeds candidate count")
    selected: list[int] = []
    available = np.ones(candidate_count, dtype=bool)
    trace: list[AcquisitionStep] = []
    for step in range(support_budget):
        scores = np.asarray(scorer(selected, available.copy()), dtype=float)
        if scores.shape != (candidate_count,):
            raise ValueError("Scorer must return one score per candidate")
        scores[~available] = -np.inf
        index = int(np.argmax(scores))
        trace.append(AcquisitionStep(step + 1, index, float(scores[index])))
        selected.append(index)
        available[index] = False
    return trace

