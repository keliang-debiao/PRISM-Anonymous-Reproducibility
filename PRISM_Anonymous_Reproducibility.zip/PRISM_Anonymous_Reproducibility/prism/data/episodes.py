"""User-level support and query episode construction."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd


@dataclass
class UserEpisode:
    user_id: str
    support: pd.DataFrame
    query: pd.DataFrame


def build_episode(
    user_rows: pd.DataFrame,
    support_budget: int,
    seed: int,
    support_indices: np.ndarray | None = None,
) -> UserEpisode:
    if support_budget < 0:
        raise ValueError("support_budget cannot be negative")
    if user_rows["user_id"].nunique() != 1:
        raise ValueError("Each episode must contain one user")
    if support_budget >= len(user_rows):
        raise ValueError("At least one query row must remain")
    if support_indices is None:
        rng = np.random.default_rng(seed)
        support_indices = rng.choice(len(user_rows), size=support_budget, replace=False)
    support = user_rows.iloc[np.asarray(support_indices, dtype=int)].copy()
    query = user_rows.drop(index=support.index).copy()
    return UserEpisode(str(user_rows["user_id"].iloc[0]), support, query)

