"""Leakage-controlled user, image, and fixed-query split construction."""

from __future__ import annotations

import hashlib
from dataclasses import dataclass
from typing import Iterable

import numpy as np
import pandas as pd

from prism.utils.reproducibility import stable_fraction


@dataclass(frozen=True)
class SplitAudit:
    user_overlap: int
    image_overlap: int
    duplicate_group_overlap: int
    fixed_query_overlap: int

    @property
    def clean(self) -> bool:
        return not any(
            [self.user_overlap, self.image_overlap, self.duplicate_group_overlap, self.fixed_query_overlap]
        )


def balanced_user_folds(
    user_ids: Iterable[str], fold_sizes: list[int], seed: int = 2026
) -> dict[str, int]:
    users = np.asarray(sorted({str(value) for value in user_ids}), dtype=object)
    if sum(fold_sizes) != len(users):
        raise ValueError("Fold sizes do not match the number of users")
    rng = np.random.default_rng(seed)
    rng.shuffle(users)
    mapping: dict[str, int] = {}
    cursor = 0
    for fold, size in enumerate(fold_sizes):
        for user in users[cursor : cursor + size]:
            mapping[str(user)] = fold
        cursor += size
    return mapping


def fixed_query_assignment(
    interactions: pd.DataFrame, acquisition_fraction: float = 0.70
) -> pd.DataFrame:
    if not 0.0 < acquisition_fraction < 1.0:
        raise ValueError("Acquisition fraction must lie between zero and one")
    result = interactions.copy()
    result["fixed_query_fraction"] = [
        stable_fraction(user, image)
        for user, image in zip(result["user_id"], result["image_id"], strict=True)
    ]
    result["fixed_query_partition"] = np.where(
        result["fixed_query_fraction"] < acquisition_fraction, "acquisition", "query"
    )
    for user, rows in result.groupby("user_id", sort=False):
        if rows["fixed_query_partition"].nunique() < 2 and len(rows) >= 2:
            ordered = rows.sort_values("fixed_query_fraction").index
            split = max(1, min(len(ordered) - 1, round(len(ordered) * acquisition_fraction)))
            result.loc[ordered[:split], "fixed_query_partition"] = "acquisition"
            result.loc[ordered[split:], "fixed_query_partition"] = "query"
    return result


def assign_duplicate_groups_to_folds(
    image_frame: pd.DataFrame, folds: int, seed: int = 2026
) -> pd.Series:
    if "duplicate_group" not in image_frame:
        raise ValueError("duplicate_group is required")
    groups = sorted(image_frame["duplicate_group"].astype(str).unique())
    scores = []
    for group in groups:
        digest = hashlib.sha256(f"{seed}:{group}".encode()).digest()
        scores.append((int.from_bytes(digest[:8], "big"), group))
    ordered = [group for _, group in sorted(scores)]
    group_fold = {group: index % folds for index, group in enumerate(ordered)}
    return image_frame["duplicate_group"].astype(str).map(group_fold).astype(int)


def audit_partition(
    train: pd.DataFrame,
    test: pd.DataFrame,
    fixed_query: pd.DataFrame | None = None,
) -> SplitAudit:
    users = len(set(train["user_id"]) & set(test["user_id"]))
    images = len(set(train["image_id"]) & set(test["image_id"]))
    duplicates = 0
    if "duplicate_group" in train and "duplicate_group" in test:
        duplicates = len(set(train["duplicate_group"]) & set(test["duplicate_group"]))
    query_overlap = 0
    if fixed_query is not None:
        acquisition = fixed_query[fixed_query["fixed_query_partition"] == "acquisition"]
        query = fixed_query[fixed_query["fixed_query_partition"] == "query"]
        query_overlap = len(
            set(zip(acquisition["user_id"], acquisition["image_id"]))
            & set(zip(query["user_id"], query["image_id"]))
        )
    return SplitAudit(users, images, duplicates, query_overlap)


def split_manifest_hash(frame: pd.DataFrame) -> str:
    columns = [column for column in frame.columns if column not in {"manifest_hash"}]
    ordered = frame[columns].sort_values(columns).to_csv(index=False).encode("utf-8")
    return hashlib.sha256(ordered).hexdigest()

