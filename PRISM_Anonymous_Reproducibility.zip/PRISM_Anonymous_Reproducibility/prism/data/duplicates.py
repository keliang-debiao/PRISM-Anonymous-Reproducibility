"""Exact and near-duplicate grouping for strict image isolation."""

from __future__ import annotations

import hashlib
from pathlib import Path

import numpy as np
from PIL import Image


def file_sha256(path: str | Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        while chunk := handle.read(1 << 20):
            digest.update(chunk)
    return digest.hexdigest()


def perceptual_hash(path: str | Path) -> str:
    import imagehash

    with Image.open(path) as image:
        return str(imagehash.phash(image.convert("RGB"), hash_size=8))


def hamming_distance(hash_a: str, hash_b: str) -> int:
    return bin(int(hash_a, 16) ^ int(hash_b, 16)).count("1")


def structural_similarity(path_a: str | Path, path_b: str | Path) -> float:
    from skimage.metrics import structural_similarity as ssim

    with Image.open(path_a) as image_a, Image.open(path_b) as image_b:
        array_a = np.asarray(image_a.convert("L").resize((256, 256)), dtype=np.float32)
        array_b = np.asarray(image_b.convert("L").resize((256, 256)), dtype=np.float32)
    return float(ssim(array_a, array_b, data_range=255.0))


def near_duplicate(
    path_a: str | Path,
    path_b: str | Path,
    phash_hamming_max: int = 4,
    ssim_min: float = 0.980,
) -> bool:
    if file_sha256(path_a) == file_sha256(path_b):
        return True
    if hamming_distance(perceptual_hash(path_a), perceptual_hash(path_b)) > phash_hamming_max:
        return False
    return structural_similarity(path_a, path_b) >= ssim_min

