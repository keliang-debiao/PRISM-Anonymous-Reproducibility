"""Canonical dataframe contracts."""

from __future__ import annotations

from dataclasses import dataclass

import pandas as pd

from prism.constants import DATASET_LIMITS


@dataclass(frozen=True)
class DatasetContract:
    name: str
    score_min: float
    score_max: float
    required_interaction_columns: tuple[str, ...] = (
        "dataset",
        "user_id",
        "image_id",
        "rating",
    )


def contract_for(name: str) -> DatasetContract:
    if name not in DATASET_LIMITS:
        raise KeyError(f"Unknown dataset: {name}")
    lower, upper = DATASET_LIMITS[name]
    return DatasetContract(name=name, score_min=lower, score_max=upper)


def validate_interactions(frame: pd.DataFrame, dataset: str) -> None:
    contract = contract_for(dataset)
    missing = set(contract.required_interaction_columns) - set(frame.columns)
    if missing:
        raise ValueError(f"Missing interaction columns: {sorted(missing)}")
    if frame.empty:
        raise ValueError("Interaction table is empty")
    if frame[["user_id", "image_id", "rating"]].isna().any().any():
        raise ValueError("Identifiers and ratings cannot be missing")
    if not (frame["dataset"].astype(str) == dataset).all():
        raise ValueError("Dataset column does not match requested adapter")
    if not frame["rating"].between(contract.score_min, contract.score_max).all():
        raise ValueError("Rating is outside the native dataset range")
    if frame.duplicated(["user_id", "image_id"]).any():
        raise ValueError("Duplicate user-image rating rows are not permitted")


def normalize_rating(values, dataset: str):
    lower, upper = DATASET_LIMITS[dataset]
    return (values - lower) / (upper - lower)

