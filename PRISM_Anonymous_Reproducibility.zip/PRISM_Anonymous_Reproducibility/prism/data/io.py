"""Canonical dataset I/O and immutable manifest construction."""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd

from prism.data.schema import validate_interactions
from prism.utils.reproducibility import sha256_file, write_json_atomic


def read_interactions(path: str | Path, dataset: str) -> pd.DataFrame:
    frame = pd.read_csv(path, dtype={"user_id": str, "image_id": str})
    validate_interactions(frame, dataset)
    return frame


def write_dataset_manifest(dataset_dir: str | Path, dataset: str) -> dict:
    root = Path(dataset_dir)
    files = [root / name for name in ("images.csv", "users.csv", "interactions.csv")]
    missing = [str(path) for path in files if not path.exists()]
    if missing:
        raise FileNotFoundError(f"Prepared files missing: {missing}")
    interactions = read_interactions(root / "interactions.csv", dataset)
    payload = {
        "dataset": dataset,
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "rows": int(len(interactions)),
        "users": int(interactions["user_id"].nunique()),
        "images": int(interactions["image_id"].nunique()),
        "files": {path.name: sha256_file(path) for path in files},
    }
    manifest_hash_input = json.dumps(payload, sort_keys=True).encode()
    import hashlib

    payload["manifest_hash"] = hashlib.sha256(manifest_hash_input).hexdigest()
    write_json_atomic(root / "dataset_manifest.json", payload)
    return payload

