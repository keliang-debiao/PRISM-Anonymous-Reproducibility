"""Torch dataset for deterministic user-level episode shards."""

from __future__ import annotations

from pathlib import Path


class EpisodeShardDataset:
    def __init__(self, root: str | Path, split: str) -> None:
        import torch

        self.root = Path(root)
        self.files = sorted(self.root.glob(f"{split}_*.pt"))
        if not self.files:
            raise FileNotFoundError(f"No {split} episode shards found under {self.root}")
        bank_path = self.root / "cohort_bank.pt"
        if not bank_path.exists():
            raise FileNotFoundError(f"Cohort bank missing: {bank_path}")
        bank = torch.load(bank_path, map_location="cpu", weights_only=True)
        self.cohort_preference = bank["preference"]
        self.cohort_sensitivity = bank["sensitivity"]
        self.cohort_user_ids = bank["user_ids"]

    def __len__(self) -> int:
        return len(self.files)

    def __getitem__(self, index: int):
        import torch

        record = torch.load(self.files[index], map_location="cpu", weights_only=True)
        record["shard_path"] = str(self.files[index])
        return record


def collate_episode_records(records: list[dict]) -> dict:
    import torch

    keys_to_stack = [
        "profile",
        "support_ratings_normalized",
        "observed",
        "ordinal_label",
        "attribute_targets",
        "attribute_mask",
    ]
    batch = {key: torch.stack([record[key] for record in records]) for key in keys_to_stack}
    levels = len(records[0]["visual_levels"])
    batch["visual_levels"] = [
        torch.stack([record["visual_levels"][level] for record in records])
        for level in range(levels)
    ]
    batch["support_visual_levels"] = [
        torch.stack([record["support_visual_levels"][level] for record in records])
        for level in range(levels)
    ]
    if "source_shared_concepts" in records[0]:
        batch["source_shared_concepts"] = torch.stack(
            [record["source_shared_concepts"] for record in records]
        )
    batch["user_index"] = torch.tensor([record["user_index"] for record in records])
    batch["user_id"] = [str(record["user_id"]) for record in records]
    batch["image_id"] = [str(record["image_id"]) for record in records]
    return batch

