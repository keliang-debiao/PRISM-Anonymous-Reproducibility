"""Protocol adapter for controlled baseline implementations."""

from __future__ import annotations

import importlib.util
from pathlib import Path
from typing import Callable

import pandas as pd
import yaml


REQUIRED_OUTPUT_COLUMNS = {
    "dataset",
    "fold",
    "seed",
    "user_id",
    "image_id",
    "support_budget",
    "observed",
    "predicted",
    "evidence_status",
}


def load_registry(path: str | Path = "configs/baselines.yaml") -> dict:
    return yaml.safe_load(Path(path).read_text(encoding="utf-8"))["baselines"]


def load_entrypoint(module_path: str | Path, function_name: str = "run_baseline") -> Callable:
    module_path = Path(module_path)
    spec = importlib.util.spec_from_file_location("prism_controlled_baseline", module_path)
    if spec is None or spec.loader is None:
        raise ImportError(module_path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    function = getattr(module, function_name, None)
    if function is None:
        raise AttributeError(f"Baseline module lacks {function_name}")
    return function


def validate_baseline_predictions(frame: pd.DataFrame) -> None:
    if missing := REQUIRED_OUTPUT_COLUMNS - set(frame.columns):
        raise ValueError(f"Baseline output columns missing: {sorted(missing)}")
    if not (frame["evidence_status"] == "empirical").all():
        raise ValueError("Controlled baseline outputs require empirical provenance")
    if frame.duplicated(["dataset", "fold", "seed", "user_id", "image_id", "support_budget"]).any():
        raise ValueError("Controlled baseline output has duplicate prediction keys")

