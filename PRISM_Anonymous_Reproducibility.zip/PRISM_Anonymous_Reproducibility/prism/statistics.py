"""Clustered intervals, paired tests, effect sizes, and multiplicity control."""

from __future__ import annotations

import numpy as np
from scipy.stats import norm, rankdata, wilcoxon


def bca_cluster_interval(
    values: np.ndarray,
    confidence: float = 0.95,
    resamples: int = 10000,
    seed: int = 2026,
) -> tuple[float, float]:
    values = np.asarray(values, dtype=float)
    values = values[np.isfinite(values)]
    if len(values) == 0:
        return np.nan, np.nan
    rng = np.random.default_rng(seed)
    statistic = float(values.mean())
    samples = rng.choice(values, size=(resamples, len(values)), replace=True).mean(axis=1)
    alpha = 1.0 - confidence
    proportion = np.clip(np.mean(samples < statistic), 1.0 / (2 * resamples), 1.0 - 1.0 / (2 * resamples))
    bias = norm.ppf(proportion)
    if len(values) < 3:
        acceleration = 0.0
    else:
        jackknife = np.asarray([np.delete(values, index).mean() for index in range(len(values))])
        centered = jackknife.mean() - jackknife
        denominator = 6.0 * np.sum(centered**2) ** 1.5
        acceleration = float(np.sum(centered**3) / denominator) if denominator > 0 else 0.0
    probabilities = []
    for tail in (alpha / 2, 1 - alpha / 2):
        normal_tail = norm.ppf(tail)
        adjusted = norm.cdf(
            bias + (bias + normal_tail) / (1.0 - acceleration * (bias + normal_tail))
        )
        probabilities.append(float(np.clip(adjusted, 0.0, 1.0)))
    return tuple(float(value) for value in np.quantile(samples, probabilities))


percentile_cluster_interval = bca_cluster_interval


def rank_biserial_paired(differences: np.ndarray) -> float:
    differences = np.asarray(differences, dtype=float)
    differences = differences[np.isfinite(differences) & (differences != 0)]
    if len(differences) == 0:
        return 0.0
    ranks = rankdata(np.abs(differences))
    positive = ranks[differences > 0].sum()
    negative = ranks[differences < 0].sum()
    return float((positive - negative) / (positive + negative))


def paired_wilcoxon(first: np.ndarray, second: np.ndarray) -> dict[str, float]:
    first = np.asarray(first, dtype=float)
    second = np.asarray(second, dtype=float)
    mask = np.isfinite(first) & np.isfinite(second)
    differences = first[mask] - second[mask]
    if not np.any(differences != 0):
        return {
            "difference": 0.0,
            "ci_lower": 0.0,
            "ci_upper": 0.0,
            "p_value": 1.0,
            "rank_biserial": 0.0,
        }
    result = wilcoxon(differences, zero_method="wilcox", alternative="two-sided")
    lower, upper = bca_cluster_interval(differences)
    return {
        "difference": float(np.mean(differences)),
        "ci_lower": lower,
        "ci_upper": upper,
        "p_value": float(result.pvalue),
        "rank_biserial": rank_biserial_paired(differences),
    }


def holm_adjust(p_values: list[float]) -> list[float]:
    values = np.asarray(p_values, dtype=float)
    order = np.argsort(values)
    adjusted = np.empty_like(values)
    running = 0.0
    count = len(values)
    for position, index in enumerate(order):
        candidate = min(1.0, (count - position) * values[index])
        running = max(running, candidate)
        adjusted[index] = running
    return adjusted.tolist()

