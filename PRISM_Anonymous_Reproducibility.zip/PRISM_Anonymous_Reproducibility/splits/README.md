# Split manifests

`protocol.json` is the immutable split specification. Dataset-specific CSV
manifests are created by `scripts/build_splits.py` after the public metadata are
prepared. Generated manifests contain `dataset`, `fold`, `user_id`, `image_id`,
`partition`, `duplicate_group`, `seed`, and `manifest_hash`.

No target-user query rating participates in training, model selection,
calibration, active acquisition, cohort construction, or monotonic mapping.
The fixed-query assignment is generated once and reused across policies,
variants, folds, support budgets, and seeds.

