#!/usr/bin/env bash
set -euo pipefail

export PYTHONPATH="${PYTHONPATH:-.}:."
python -m compileall -q prism scripts tests
python scripts/run_workflow_validation.py
python scripts/run_unit_checks.py
python scripts/check_release.py --root .

