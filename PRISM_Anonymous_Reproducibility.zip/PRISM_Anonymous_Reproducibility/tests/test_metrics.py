import numpy as np

from prism.metrics import brier_score, expected_calibration_error, regression_metrics


def test_perfect_regression_metrics():
    observed = np.arange(1.0, 6.0)
    result = regression_metrics(observed, observed.copy())
    assert np.isclose(result["srocc"], 1.0)
    assert np.isclose(result["plcc"], 1.0)
    assert result["mae"] == 0.0
    assert result["rmse"] == 0.0


def test_probability_metrics_are_finite():
    probabilities = np.eye(5)
    labels = np.arange(5)
    assert expected_calibration_error(probabilities, labels) == 0.0
    assert brier_score(probabilities, labels) == 0.0

