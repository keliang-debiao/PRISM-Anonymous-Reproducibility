import numpy as np

from prism.calibration import prediction_intervals


def test_interval_mapping_and_clipping():
    mean = np.array([0.0, 2.0, 4.0])
    variance = np.array([1.0, 0.1, 1.0])
    result = prediction_intervals(mean, variance, 1.0, lambda x: x, 1.0, 5.0)
    assert np.all(result["lower_bounded"] >= 1.0)
    assert np.all(result["upper_bounded"] <= 5.0)
    assert result["clipped"].any()

