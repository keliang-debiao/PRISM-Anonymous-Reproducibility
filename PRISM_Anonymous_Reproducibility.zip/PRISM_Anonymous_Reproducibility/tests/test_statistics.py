from prism.statistics import holm_adjust


def test_holm_adjustment_is_order_preserving_after_sort():
    adjusted = holm_adjust([0.001, 0.02, 0.40])
    assert 0.0 <= adjusted[0] <= adjusted[1] <= adjusted[2] <= 1.0

