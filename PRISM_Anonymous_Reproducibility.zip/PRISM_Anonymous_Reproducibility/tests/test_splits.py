import pandas as pd

from prism.data.splits import fixed_query_assignment


def test_fixed_query_is_stable_and_disjoint():
    frame = pd.DataFrame(
        {
            "user_id": ["u1"] * 30 + ["u2"] * 30,
            "image_id": [f"i{index}" for index in range(60)],
        }
    )
    first = fixed_query_assignment(frame)
    second = fixed_query_assignment(frame)
    assert first["fixed_query_partition"].equals(second["fixed_query_partition"])
    for _, block in first.groupby("user_id"):
        assert set(block["fixed_query_partition"]) == {"acquisition", "query"}

