import json
import tempfile
from pathlib import Path

from prism.provenance import require_empirical


def test_workflow_record_cannot_build_manuscript_artifacts():
    with tempfile.TemporaryDirectory() as directory:
        path = Path(directory) / "provenance.json"
        path.write_text(json.dumps({"evidence_status": "workflow_validation"}), encoding="utf-8")
        try:
            require_empirical([path])
        except ValueError:
            return
        raise AssertionError("A non-empirical record passed the provenance gate")

