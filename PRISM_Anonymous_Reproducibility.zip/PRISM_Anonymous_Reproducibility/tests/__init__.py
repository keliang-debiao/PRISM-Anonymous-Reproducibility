"""Deterministic checks for core protocol functions."""

