import numpy as np

from prism.acquisition import acquisition_score, sequential_select


def test_first_step_has_zero_personalized_deviation():
    rng = np.random.default_rng(2026)
    population = rng.dirichlet(np.ones(5), size=12)
    user = rng.dirichlet(np.ones(5), size=12)
    concepts = rng.normal(size=(12, 16))
    score, terms = acquisition_score(
        population,
        user,
        concepts,
        None,
        concepts.mean(axis=0),
        rng.uniform(size=12),
        first_step=True,
    )
    assert score.shape == (12,)
    assert np.allclose(terms["personalized_deviation"], 0.0)


def test_sequential_selection_has_no_repeats():
    values = np.arange(20, dtype=float)
    trace = sequential_select(20, 10, lambda selected, available: values.copy())
    indices = [step.selected_index for step in trace]
    assert len(indices) == len(set(indices)) == 10

