#!/usr/bin/env python3
"""Build manuscript result tables from empirical aggregate artifacts."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd

from prism.provenance import require_empirical


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--runs", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    provenance = sorted(args.runs.glob("**/provenance.json"))
    require_empirical(provenance)
    metric_files = sorted(args.runs.glob("**/metrics.json"))
    rows = []
    for path in metric_files:
        payload = json.loads(path.read_text(encoding="utf-8"))
        rows.append({"run": str(path.parent.relative_to(args.runs)), **payload})
    args.output.mkdir(parents=True, exist_ok=True)
    pd.json_normalize(rows).to_csv(args.output / "aggregate_metrics.csv", index=False)


if __name__ == "__main__":
    main()

