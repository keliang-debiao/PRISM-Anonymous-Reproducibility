#!/usr/bin/env python3
"""Extract frozen multilevel Qwen3-VL features with resumable caching."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd

from prism.models.backbone import Qwen3VLFeatureExtractor, save_feature_record
from prism.utils.reproducibility import sha256_file


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset", required=True, choices=["para", "flickr_aes", "lapis"])
    parser.add_argument("--prepared-root", type=Path, default=Path("prepared_data"))
    parser.add_argument("--image-root", required=True, type=Path)
    parser.add_argument("--output", type=Path, default=Path("feature_cache"))
    parser.add_argument("--backbone", default="Qwen/Qwen3-VL-4B-Instruct")
    parser.add_argument("--overwrite", action="store_true")
    args = parser.parse_args()
    images = pd.read_csv(args.prepared_root / args.dataset / "images.csv", dtype={"image_id": str})
    extractor = Qwen3VLFeatureExtractor(model_name=args.backbone)
    target_root = args.output / args.dataset
    target_root.mkdir(parents=True, exist_ok=True)
    records = []
    for row in images.itertuples(index=False):
        target = target_root / f"{row.image_id}.npz"
        if not target.exists() or args.overwrite:
            features = extractor.extract(args.image_root / row.relative_path)
            save_feature_record(target, row.image_id, features)
        records.append({"image_id": row.image_id, "path": target.name, "sha256": sha256_file(target)})
    (target_root / "manifest.json").write_text(
        json.dumps({"dataset": args.dataset, "layers": [5, 11, 17, 23], "files": records}, indent=2),
        encoding="utf-8",
    )


if __name__ == "__main__":
    main()

