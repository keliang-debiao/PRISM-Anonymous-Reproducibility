#!/usr/bin/env python3
"""Evaluate acquisition policies on an identical frozen query set."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd

from prism.acquisition import acquisition_score, sequential_select
from prism.metrics import aggregate_user_metrics, per_user_metrics


POLICIES = ("random", "controversy", "uncertainty", "prac_preferselect", "prism")


def parse_array(value: str) -> np.ndarray:
    return np.asarray(json.loads(value), dtype=float)


def select_for_user(pool: pd.DataFrame, budget: int, policy: str, seed: int) -> list[int]:
    population = np.stack(pool["population_probabilities"].map(parse_array))
    user = np.stack(pool["user_probabilities"].map(parse_array))
    concepts = np.stack(pool["concept_activations"].map(parse_array))
    uncertainty = pool["predictive_uncertainty"].to_numpy(dtype=float)
    centroid = concepts.mean(axis=0)
    rng = np.random.default_rng(seed)

    def scorer(selected: list[int], available: np.ndarray) -> np.ndarray:
        support = concepts[selected] if selected else None
        full, terms = acquisition_score(
            population, user, concepts, support, centroid, uncertainty, first_step=not selected
        )
        if policy == "random":
            return rng.random(len(pool))
        if policy == "controversy":
            return terms["controversy"]
        if policy == "uncertainty":
            return terms["predictive_uncertainty"]
        if policy == "prac_preferselect":
            return 0.60 * terms["controversy"] + 0.40 * terms["personalized_deviation"]
        return full

    return [step.selected_index for step in sequential_select(len(pool), budget, scorer)]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--candidate-file", required=True, type=Path)
    parser.add_argument("--query-predictions", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--budgets", nargs="+", type=int, default=[5, 10, 20])
    args = parser.parse_args()
    candidates = pd.read_csv(args.candidate_file)
    query = pd.read_csv(args.query_predictions)
    args.output.mkdir(parents=True, exist_ok=True)
    traces = []
    results = []
    for policy in POLICIES:
        for budget in args.budgets:
            for seed in range(2026, 2031):
                for user, pool in candidates.groupby("user_id", sort=True):
                    selected = select_for_user(pool.reset_index(drop=True), budget, policy, seed)
                    for step, index in enumerate(selected, start=1):
                        traces.append(
                            {
                                "policy": policy,
                                "budget": budget,
                                "seed": seed,
                                "user_id": user,
                                "step": step,
                                "image_id": pool.iloc[index]["image_id"],
                            }
                        )
                block = query[
                    (query["policy"] == policy)
                    & (query["support_budget"] == budget)
                    & (query["seed"] == seed)
                ]
                if len(block):
                    summary = aggregate_user_metrics(per_user_metrics(block))
                    results.append({"policy": policy, "budget": budget, "seed": seed, **summary})
    pd.DataFrame(traces).to_csv(args.output / "acquisition_trace.csv", index=False)
    pd.DataFrame(results).to_csv(args.output / "fixed_query_metrics.csv", index=False)


if __name__ == "__main__":
    main()

