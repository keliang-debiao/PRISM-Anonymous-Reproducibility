#!/usr/bin/env python3
"""Compare empirical summaries with immutable manuscript targets."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from prism.provenance import require_empirical


def flatten(prefix: str, value, output: dict[str, float]) -> None:
    if isinstance(value, dict):
        for key, child in value.items():
            flatten(f"{prefix}.{key}" if prefix else key, child, output)
    elif isinstance(value, (int, float)):
        output[prefix] = float(value)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--runs", required=True, type=Path)
    parser.add_argument("--targets", required=True, type=Path)
    parser.add_argument("--absolute-tolerance", type=float, default=0.003)
    args = parser.parse_args()
    provenance = sorted(args.runs.glob("**/provenance.json"))
    require_empirical(provenance)
    observed_path = args.runs / "aggregate_metrics.json"
    if not observed_path.exists():
        raise FileNotFoundError(observed_path)
    targets = json.loads(args.targets.read_text(encoding="utf-8"))
    observed = json.loads(observed_path.read_text(encoding="utf-8"))
    target_values: dict[str, float] = {}
    observed_values: dict[str, float] = {}
    flatten("", targets.get("verification_targets", {}), target_values)
    flatten("", observed, observed_values)
    failures = []
    for key, target in target_values.items():
        if key in observed_values and abs(observed_values[key] - target) > args.absolute_tolerance:
            failures.append((key, observed_values[key], target))
    if failures:
        raise SystemExit("Target differences exceed tolerance: " + repr(failures))
    print(f"verified_metrics={len(set(target_values) & set(observed_values))}")


if __name__ == "__main__":
    main()

