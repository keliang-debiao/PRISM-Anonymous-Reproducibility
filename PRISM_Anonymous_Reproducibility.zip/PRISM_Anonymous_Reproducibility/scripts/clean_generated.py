#!/usr/bin/env python3
"""Remove only known generated workspace directories."""

from __future__ import annotations

import argparse
import shutil
from pathlib import Path


ALLOWED = ("prepared_data", "feature_cache", "checkpoints", "runs", "artifacts", ".pytest_cache")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path("."))
    args = parser.parse_args()
    root = args.root.resolve()
    for name in ALLOWED:
        target = root / name
        if target.exists() and target.parent == root:
            shutil.rmtree(target)


if __name__ == "__main__":
    main()

