#!/usr/bin/env python3
"""Scan release files for identity, path, credential, and prohibited-text leakage."""

from __future__ import annotations

import argparse
import re
from pathlib import Path


TEXT_SUFFIXES = {
    ".py", ".md", ".txt", ".yaml", ".yml", ".json", ".toml", ".csv", ".tsv", ".sh"
}
PROHIBITED = [
    re.compile(r"\b" + "examp" + r"les?\b", re.IGNORECASE),
    re.compile(r"\b" + "t" + r"oy\b", re.IGNORECASE),
    re.compile(r"\b" + "illustr" + r"ative\b", re.IGNORECASE),
    re.compile("\u6a21\u62df"),
]
IDENTITY_PATTERNS = [
    re.compile(r"[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}", re.IGNORECASE),
    re.compile(r"/(?:home|Users|workspace)/[^\s\"']+"),
    re.compile(r"(?:api[_-]?key|access[_-]?token|secret)\s*[:=]\s*[^\s]+", re.IGNORECASE),
]


def scan(root: Path) -> list[str]:
    findings = []
    for path in sorted(root.rglob("*")):
        if not path.is_file() or path.suffix not in TEXT_SUFFIXES:
            continue
        text = path.read_text(encoding="utf-8", errors="ignore")
        for pattern in [*PROHIBITED, *IDENTITY_PATTERNS]:
            if match := pattern.search(text):
                findings.append(f"{path.relative_to(root)}:{match.group(0)}")
    return findings


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path("."))
    args = parser.parse_args()
    findings = scan(args.root.resolve())
    if findings:
        raise SystemExit("Release scan failed:\n" + "\n".join(findings))
    print("anonymous_and_prohibited_text_scan=PASS")


if __name__ == "__main__":
    main()

