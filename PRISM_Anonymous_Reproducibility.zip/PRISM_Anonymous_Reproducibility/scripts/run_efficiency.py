#!/usr/bin/env python3
"""Measure cached and full five-member latency under declared pool sizes."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from prism.benchmark import benchmark_callable


def load_callable(module_path: str, attribute: str):
    import importlib.util

    spec = importlib.util.spec_from_file_location("prism_benchmark_target", module_path)
    if spec is None or spec.loader is None:
        raise ImportError(module_path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return getattr(module, attribute)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--target-module", required=True)
    parser.add_argument("--cached-callable", default="run_cached")
    parser.add_argument("--full-callable", default="run_full")
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--support-budget", type=int, default=10)
    parser.add_argument("--pools", nargs="+", type=int, default=[50, 100, 200, 500])
    args = parser.parse_args()
    cached = load_callable(args.target_module, args.cached_callable)
    full = load_callable(args.target_module, args.full_callable)
    records = []
    for pool in args.pools:
        records.append(
            {
                "mode": "cached",
                **benchmark_callable(
                    lambda: cached(pool, args.support_budget),
                    candidate_pool=pool,
                    support_budget=args.support_budget,
                ).__dict__,
            }
        )
        records.append(
            {
                "mode": "full",
                **benchmark_callable(
                    lambda: full(pool, args.support_budget),
                    includes_visual_encoding=True,
                    candidate_pool=pool,
                    support_budget=args.support_budget,
                ).__dict__,
            }
        )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(records, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()

