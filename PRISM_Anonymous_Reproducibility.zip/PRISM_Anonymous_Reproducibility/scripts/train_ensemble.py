#!/usr/bin/env python3
"""Train five independently initialized PRISM members from episode shards."""

from __future__ import annotations

import argparse
import copy
import json
import math
from pathlib import Path

import torch
import pandas as pd
from torch.nn import functional as F
from torch.utils.data import DataLoader

from prism.config import load_config
from prism.data.torch_dataset import EpisodeShardDataset, collate_episode_records
from prism.losses import (
    cohort_contrastive_loss,
    deep_coral_loss,
    masked_attribute_loss,
    pairwise_rank_loss,
    regularization_loss,
    total_loss,
)
from prism.metrics import aggregate_user_metrics, per_user_metrics
from prism.models.prism import PRISMMember
from prism.engine import EarlyStopping
from prism.utils.reproducibility import runtime_provenance, set_seed, write_json_atomic


def move(value, device):
    if isinstance(value, torch.Tensor):
        return value.to(device)
    if isinstance(value, list) and value and isinstance(value[0], torch.Tensor):
        return [item.to(device) for item in value]
    return value


def build_member(config: dict, visual_dim: int, profile_dim: int) -> PRISMMember:
    dataset = config["dataset"]
    model = config["model"]
    return PRISMMember(
        visual_dim=visual_dim,
        support_token_dim=model["hidden_dim"] + 18,
        profile_dim=profile_dim,
        score_min=dataset["score_min"],
        score_max=dataset["score_max"],
        hidden_dim=model["hidden_dim"],
        experts=model["experts"],
    )


def within_user_pairs(user_index: torch.Tensor, observed: torch.Tensor) -> torch.Tensor:
    pairs = []
    for left in range(len(user_index)):
        for right in range(left + 1, len(user_index)):
            if user_index[left] == user_index[right] and observed[left] != observed[right]:
                pairs.append((left, right))
    if not pairs:
        return torch.empty((0, 2), dtype=torch.long, device=user_index.device)
    return torch.tensor(pairs, dtype=torch.long, device=user_index.device)


def positive_cohort_mask(
    user_index: torch.Tensor,
    cohort_preference: torch.Tensor,
    neighbors: int = 6,
) -> torch.Tensor:
    selected = cohort_preference[user_index.long()]
    normalized_selected = F.normalize(selected, dim=-1)
    normalized_bank = F.normalize(cohort_preference, dim=-1)
    nearest = (normalized_selected @ normalized_bank.T).topk(
        min(neighbors + 1, len(cohort_preference)), dim=1
    ).indices
    mask = torch.zeros((len(user_index), len(user_index)), dtype=torch.bool, device=user_index.device)
    for row in range(len(user_index)):
        allowed = set(nearest[row].tolist()) - {int(user_index[row])}
        for column in range(len(user_index)):
            mask[row, column] = row != column and int(user_index[column]) in allowed
    return mask


@torch.no_grad()
def selection_srocc(model, loader, cohort_preference, cohort_sensitivity, device) -> float:
    model.eval()
    rows = []
    for batch in loader:
        batch = {key: move(value, device) for key, value in batch.items()}
        output = model(
            visual_levels=batch["visual_levels"],
            support_tokens=None,
            support_visual_levels=batch["support_visual_levels"],
            support_ratings_normalized=batch["support_ratings_normalized"],
            profile=batch["profile"],
            cohort_preference=cohort_preference,
            cohort_sensitivity=cohort_sensitivity,
        )
        for index, user in enumerate(batch["user_id"]):
            rows.append(
                {
                    "user_id": user,
                    "observed": float(batch["observed"][index].detach().cpu()),
                    "predicted": float(output.native_mean[index].detach().cpu()),
                }
            )
    model.train()
    return aggregate_user_metrics(per_user_metrics(pd.DataFrame(rows)))["srocc"]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True, type=Path)
    parser.add_argument("--shards", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--visual-dim", type=int, required=True)
    parser.add_argument("--profile-dim", type=int, required=True)
    parser.add_argument("--dataset-manifest-hash", required=True)
    parser.add_argument("--split-manifest-hash", required=True)
    args = parser.parse_args()
    config = load_config(args.config)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    dataset = EpisodeShardDataset(args.shards, "train")
    selection_dataset = EpisodeShardDataset(args.shards, "selection")
    loader = DataLoader(
        dataset,
        batch_size=config["training"]["episodes_per_gpu"],
        shuffle=True,
        collate_fn=collate_episode_records,
    )
    selection_loader = DataLoader(
        selection_dataset,
        batch_size=config["training"]["episodes_per_gpu"],
        shuffle=False,
        collate_fn=collate_episode_records,
    )
    args.output.mkdir(parents=True, exist_ok=True)
    for member_index, seed in enumerate(config["reproducibility"]["seeds"]):
        set_seed(seed)
        model = build_member(config, args.visual_dim, args.profile_dim).to(device)
        cohort_preference = dataset.cohort_preference.to(device).clone()
        cohort_sensitivity = dataset.cohort_sensitivity.to(device).clone()
        optimizer = torch.optim.AdamW(
            model.parameters(),
            lr=config["training"]["learning_rates"]["new_modules"],
            betas=(config["training"]["beta1"], config["training"]["beta2"]),
            weight_decay=config["training"]["weight_decay"],
        )
        total_steps = max(1, config["training"]["max_epochs"] * len(loader))
        warmup = max(1, round(total_steps * config["training"]["warmup_fraction"]))
        scheduler = torch.optim.lr_scheduler.LambdaLR(
            optimizer,
            lambda step: step / warmup if step < warmup else 0.5 * (1 + math.cos(math.pi * (step - warmup) / max(1, total_steps - warmup))),
        )
        log_rows = []
        early_stopping = EarlyStopping(config["training"]["early_stopping_evaluations"])
        best_state = copy.deepcopy(model.state_dict())
        stop = False
        global_step = 0
        for epoch in range(config["training"]["max_epochs"]):
            model.train()
            for step, batch in enumerate(loader):
                batch = {key: move(value, device) for key, value in batch.items()}
                optimizer.zero_grad(set_to_none=True)
                output = model(
                    visual_levels=batch["visual_levels"],
                    support_tokens=None,
                    support_visual_levels=batch["support_visual_levels"],
                    support_ratings_normalized=batch["support_ratings_normalized"],
                    profile=batch["profile"],
                    cohort_preference=cohort_preference,
                    cohort_sensitivity=cohort_sensitivity,
                )
                score = (0.5 * (batch["observed"] - output.native_mean).square() / output.aleatoric_variance + 0.5 * output.aleatoric_variance.log()).mean()
                pairs = within_user_pairs(batch["user_index"], batch["observed"])
                rank = (
                    pairwise_rank_loss(output.latent_score, batch["observed"], pairs)
                    if len(pairs)
                    else score.new_zeros(())
                )
                ordinal = F.cross_entropy(output.ordinal_logits, batch["ordinal_label"].long())
                attribute = masked_attribute_loss(
                    output.concepts, batch["attribute_targets"], batch["attribute_mask"]
                )
                positive_mask = positive_cohort_mask(batch["user_index"], cohort_preference)
                cohort = (
                    cohort_contrastive_loss(output.preference_embedding, positive_mask)
                    if positive_mask.any()
                    else score.new_zeros(())
                )
                zero = score.new_zeros(())
                domain = zero
                if config["domain_alignment"]["enabled"]:
                    domain = deep_coral_loss(batch["source_shared_concepts"], output.concepts[:, :10])
                regularization = regularization_loss(
                    output.bounded_residual,
                    output.routing_weights,
                    model.concept_residual.query,
                )
                loss = total_loss(score, rank, attribute, cohort, domain, ordinal, regularization)
                loss.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(), config["training"]["gradient_clip"])
                optimizer.step()
                scheduler.step()
                global_step += 1
                with torch.no_grad():
                    indices = batch["user_index"].long()
                    cohort_preference[indices] = (
                        0.90 * cohort_preference[indices]
                        + 0.10 * output.preference_embedding.detach()
                    )
                    cohort_sensitivity[indices] = (
                        0.90 * cohort_sensitivity[indices]
                        + 0.10 * output.concept_sensitivities.detach()
                    )
                log_rows.append({"epoch": epoch + 1, "step": step + 1, "loss": float(loss.detach().cpu())})
                if global_step % config["training"]["evaluation_steps"] == 0:
                    validation_srocc = selection_srocc(
                        model, selection_loader, cohort_preference, cohort_sensitivity, device
                    )
                    log_rows.append(
                        {"epoch": epoch + 1, "global_step": global_step, "selection_srocc": validation_srocc}
                    )
                    if validation_srocc > early_stopping.best:
                        best_state = copy.deepcopy(model.state_dict())
                    if early_stopping.update(validation_srocc):
                        stop = True
                        break
            if stop:
                break
            validation_srocc = selection_srocc(
                model, selection_loader, cohort_preference, cohort_sensitivity, device
            )
            log_rows.append({"epoch": epoch + 1, "selection_srocc": validation_srocc})
            if validation_srocc > early_stopping.best:
                best_state = copy.deepcopy(model.state_dict())
            if early_stopping.update(validation_srocc):
                stop = True
            if stop:
                break
        model.load_state_dict(best_state)
        member_dir = args.output / f"member_{member_index + 1}_seed_{seed}"
        member_dir.mkdir(parents=True, exist_ok=True)
        torch.save(model.state_dict(), member_dir / "adapter_state.pt")
        torch.save(
            {
                "preference": cohort_preference.detach().cpu(),
                "sensitivity": cohort_sensitivity.detach().cpu(),
                "user_ids": dataset.cohort_user_ids,
            },
            member_dir / "cohort_bank.pt",
        )
        write_json_atomic(member_dir / "training_log.json", log_rows)
        provenance = runtime_provenance(
            ["train_ensemble.py", "--config", str(args.config)],
            "empirical",
            args.dataset_manifest_hash,
            args.split_manifest_hash,
            seed,
        )
        provenance["completed"] = True
        write_json_atomic(member_dir / "provenance.json", provenance)


if __name__ == "__main__":
    main()

