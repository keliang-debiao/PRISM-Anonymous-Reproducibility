#!/usr/bin/env python3
"""Orchestrate fold-wise feature-cache training, calibration, inference, and evaluation."""

from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path

import numpy as np

from prism.config import load_config
from prism.utils.reproducibility import sha256_file


def call(arguments: list[str]) -> None:
    subprocess.run([sys.executable, *arguments], check=True)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True, type=Path)
    parser.add_argument("--prepared-root", type=Path, default=Path("prepared_data"))
    parser.add_argument("--feature-root", type=Path, default=Path("feature_cache"))
    parser.add_argument("--split-manifest", required=True, type=Path)
    parser.add_argument("--run-root", type=Path, default=Path("runs"))
    parser.add_argument("--support-budget", type=int, default=10)
    parser.add_argument("--source-concepts", type=Path)
    args = parser.parse_args()
    config = load_config(args.config)
    dataset = config["dataset"]["name"]
    folds = int(config.get("protocol", {}).get("outer_folds", 1))
    dataset_manifest = json.loads(
        (args.prepared_root / dataset / "dataset_manifest.json").read_text(encoding="utf-8")
    )
    first_feature = next((args.feature_root / dataset).glob("*.npz"))
    with np.load(first_feature) as archive:
        visual_dim = int(archive["layer_0"].shape[-1])
    for fold in range(folds):
        fold_root = args.run_root / dataset / "primary" / f"fold_{fold}"
        shards = fold_root / "episode_shards"
        checkpoint_root = fold_root / "checkpoints"
        calibration_predictions = fold_root / "calibration_predictions.csv"
        calibration_file = fold_root / "calibration.json"
        test_predictions = fold_root / "predictions.csv"
        metrics_root = fold_root / "metrics"
        shard_command = [
            "scripts/build_episode_shards.py",
            "--config", str(args.config),
            "--prepared-root", str(args.prepared_root),
            "--feature-root", str(args.feature_root),
            "--split-manifest", str(args.split_manifest),
            "--fold", str(fold),
            "--support-budget", str(args.support_budget),
            "--output", str(shards),
        ]
        if args.source_concepts:
            shard_command.extend(["--source-concepts", str(args.source_concepts)])
        call(shard_command)
        shard_manifest = json.loads((shards / "shard_manifest.json").read_text(encoding="utf-8"))
        profile_dim = int(shard_manifest["profile_dim"])
        call(
            [
                "scripts/train_ensemble.py",
                "--config", str(args.config),
                "--shards", str(shards),
                "--output", str(checkpoint_root),
                "--visual-dim", str(visual_dim),
                "--profile-dim", str(profile_dim),
                "--dataset-manifest-hash", dataset_manifest["manifest_hash"],
                "--split-manifest-hash", sha256_file(args.split_manifest),
            ]
        )
        common_inference = [
            "scripts/infer.py",
            "--config", str(args.config),
            "--shards", str(shards),
            "--checkpoint-root", str(checkpoint_root),
            "--visual-dim", str(visual_dim),
            "--profile-dim", str(profile_dim),
            "--fold", str(fold),
            "--support-budget", str(args.support_budget),
        ]
        call([*common_inference, "--split", "calibration", "--output", str(calibration_predictions)])
        call(
            [
                "scripts/calibrate.py",
                "--predictions", str(calibration_predictions),
                "--output", str(calibration_file),
            ]
        )
        call(
            [
                *common_inference,
                "--split", "test",
                "--calibration", str(calibration_file),
                "--output", str(test_predictions),
            ]
        )
        call(
            [
                "scripts/evaluate.py",
                "--predictions", str(test_predictions),
                "--output", str(metrics_root),
            ]
        )


if __name__ == "__main__":
    main()

