#!/usr/bin/env python3
"""Normalize public metadata into the canonical PRISM data contract."""

from __future__ import annotations

import argparse
import shutil
from pathlib import Path

import pandas as pd

from prism.data.io import write_dataset_manifest
from prism.data.schema import validate_interactions


COLUMN_ALIASES = {
    "user_id": ["user_id", "user", "rater_id", "annotator_id", "uid"],
    "image_id": ["image_id", "image", "photo_id", "artwork_id", "iid"],
    "rating": ["rating", "score", "aesthetic_score", "preference_score"],
    "relative_path": ["relative_path", "image_path", "path", "filename"],
}


def locate(root: Path, names: list[str]) -> Path:
    for name in names:
        for candidate in (root / name, root / "metadata" / name):
            if candidate.exists():
                return candidate
    raise FileNotFoundError(f"Required metadata not found under {root}: {names}")


def rename_known_columns(frame: pd.DataFrame) -> pd.DataFrame:
    rename = {}
    for canonical, aliases in COLUMN_ALIASES.items():
        for alias in aliases:
            if alias in frame.columns:
                rename[alias] = canonical
                break
    return frame.rename(columns=rename)


def prepare(dataset: str, root: Path, output: Path) -> None:
    interactions_path = locate(root, ["interactions.csv", "ratings.csv", "scores.csv"])
    images_path = locate(root, ["images.csv", "image_metadata.csv", "artworks.csv"])
    users_path = locate(root, ["users.csv", "user_metadata.csv", "participants.csv"])
    interactions = rename_known_columns(pd.read_csv(interactions_path))
    images = rename_known_columns(pd.read_csv(images_path))
    users = rename_known_columns(pd.read_csv(users_path))
    for frame in (interactions, images, users):
        for identifier in ("user_id", "image_id"):
            if identifier in frame:
                frame[identifier] = frame[identifier].astype(str)
    interactions["dataset"] = dataset
    validate_interactions(interactions, dataset)
    if dataset in {"para", "flickr_aes"} and "official_partition" not in interactions:
        if "official_partition" in users:
            interactions = interactions.merge(
                users[["user_id", "official_partition"]], on="user_id", how="left", validate="many_to_one"
            )
        else:
            raise ValueError(
                f"{dataset} requires provider-supplied official_partition metadata"
            )
    if "relative_path" not in images:
        raise ValueError("Image metadata require a relative_path column")
    output.mkdir(parents=True, exist_ok=True)
    interactions.to_csv(output / "interactions.csv", index=False)
    images.to_csv(output / "images.csv", index=False)
    users.to_csv(output / "users.csv", index=False)
    attribute_map = root / "attribute_map.json"
    if attribute_map.exists():
        shutil.copy2(attribute_map, output / "attribute_map.json")
    write_dataset_manifest(output, dataset)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset", required=True, choices=["para", "flickr_aes", "lapis"])
    parser.add_argument("--root", required=True, type=Path)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    output = args.output or Path("prepared_data") / args.dataset
    prepare(args.dataset, args.root.resolve(), output.resolve())


if __name__ == "__main__":
    main()

