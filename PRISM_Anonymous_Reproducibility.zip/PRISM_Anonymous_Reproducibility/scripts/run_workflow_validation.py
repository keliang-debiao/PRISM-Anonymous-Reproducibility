#!/usr/bin/env python3
"""Run deterministic CPU checks without asserting manuscript performance."""

from __future__ import annotations

import json
import tempfile
from pathlib import Path

import numpy as np
import pandas as pd

from prism.acquisition import acquisition_score, sequential_select
from prism.calibration import fit_temperature, fit_variance_multiplier, prediction_intervals
from prism.config import load_config
from prism.data.splits import fixed_query_assignment
from prism.metrics import brier_score, expected_calibration_error, regression_metrics
from prism.provenance import require_empirical
from prism.statistics import holm_adjust, paired_wilcoxon


def main() -> None:
    rng = np.random.default_rng(2026)
    config = load_config("configs/para.yaml")
    print("evidence_status=workflow_validation")
    print(f"concepts={config['model']['concepts']}")
    print(f"ensemble_members={config['model']['ensemble_members']}")

    interactions = pd.DataFrame(
        {
            "dataset": "para",
            "user_id": np.repeat(["u01", "u02", "u03"], 20),
            "image_id": [f"i{index:03d}" for index in range(60)],
            "rating": rng.integers(1, 6, 60),
        }
    )
    fixed = fixed_query_assignment(interactions)
    counts = fixed.groupby(["user_id", "fixed_query_partition"]).size().unstack(fill_value=0)
    assert (counts > 0).all().all()
    repeated = fixed_query_assignment(interactions)
    assert fixed["fixed_query_partition"].equals(repeated["fixed_query_partition"])
    print("fixed_query_deterministic=PASS")

    population = rng.dirichlet(np.ones(5), size=30)
    user = rng.dirichlet(np.ones(5), size=30)
    concepts = rng.normal(size=(30, 16))
    uncertainty = rng.uniform(0.01, 0.20, size=30)
    score, terms = acquisition_score(
        population,
        user,
        concepts,
        None,
        concepts.mean(axis=0),
        uncertainty,
        first_step=True,
    )
    assert np.allclose(terms["personalized_deviation"], 0.0)
    trace = sequential_select(30, 10, lambda selected, available: score.copy())
    assert len({step.selected_index for step in trace}) == 10
    print("sequential_acquisition=PASS")

    logits = rng.normal(size=(120, 5))
    labels = rng.integers(0, 5, 120)
    temperature = fit_temperature(logits, labels)
    observed = rng.uniform(1.0, 5.0, 120)
    mean = np.clip(observed + rng.normal(0, 0.4, 120), 1.0, 5.0)
    variance = rng.uniform(0.03, 0.20, 120)
    multiplier = fit_variance_multiplier(observed, mean, variance)
    intervals = prediction_intervals(
        mean,
        variance,
        multiplier,
        lambda values: values,
        1.0,
        5.0,
    )
    assert (intervals["lower_bounded"] >= 1.0).all()
    assert (intervals["upper_bounded"] <= 5.0).all()
    print(f"calibration_temperature={temperature:.6f}")
    print(f"variance_multiplier={multiplier:.6f}")
    print("interval_boundary_handling=PASS")

    metrics = regression_metrics(observed, mean)
    probabilities = np.exp(logits / temperature)
    probabilities /= probabilities.sum(axis=1, keepdims=True)
    assert 0.0 <= expected_calibration_error(probabilities, labels) <= 1.0
    assert brier_score(probabilities, labels) >= 0.0
    paired = paired_wilcoxon(rng.normal(0.72, 0.03, 40), rng.normal(0.70, 0.03, 40))
    adjusted = holm_adjust([0.001, 0.02, 0.40])
    assert adjusted[0] <= adjusted[1] <= adjusted[2]
    print("metric_and_statistics_checks=PASS")

    with tempfile.TemporaryDirectory() as directory:
        path = Path(directory) / "provenance.json"
        path.write_text(json.dumps({"evidence_status": "workflow_validation"}), encoding="utf-8")
        try:
            require_empirical([path])
        except ValueError:
            print("provenance_gate=PASS")
        else:
            raise AssertionError("Provenance gate accepted a non-empirical record")
    print("workflow_validation=PASS")


if __name__ == "__main__":
    main()

