#!/usr/bin/env python3
"""Materialize resolved configurations for every prespecified ablation."""

from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path

import yaml

from prism.config import load_config


def apply_variant(config: dict, name: str) -> dict:
    result = copy.deepcopy(config)
    result["ablation"] = name
    if name == "random_support":
        result["acquisition"]["policy"] = "random"
    elif name.startswith("no_") and name.replace("no_", "") in result["acquisition"]["weights"]:
        result["acquisition"]["weights"][name.replace("no_", "")] = 0.0
    elif name == "no_controversy":
        result["acquisition"]["weights"]["controversy"] = 0.0
    elif name == "no_personalized_deviation":
        result["acquisition"]["weights"]["personalized_deviation"] = 0.0
    elif name == "no_concept_novelty":
        result["acquisition"]["weights"]["concept_novelty"] = 0.0
    elif name == "no_uncertainty_acquisition":
        result["acquisition"]["weights"]["predictive_uncertainty"] = 0.0
    elif name == "single_low_rank_expert":
        result["model"]["experts"] = 1
        result["model"]["active_experts"] = 1
    elif name == "no_concept_domain_alignment":
        result["domain_alignment"]["enabled"] = False
    else:
        result.setdefault("module_switches", {})[name] = False
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True, type=Path)
    parser.add_argument("--ablation-config", type=Path, default=Path("configs/ablation.yaml"))
    parser.add_argument("--output", type=Path, default=Path("runs/ablation_configs"))
    args = parser.parse_args()
    base = load_config(args.config)
    variants = yaml.safe_load(args.ablation_config.read_text(encoding="utf-8"))["variants"]
    args.output.mkdir(parents=True, exist_ok=True)
    for name in variants:
        payload = apply_variant(base, name)
        (args.output / f"{name}.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()

