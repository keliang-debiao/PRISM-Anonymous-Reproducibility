#!/usr/bin/env python3
"""Validate repository structure and optional empirical artifact completeness."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from prism.constants import SEEDS
from scripts.anonymize_check import scan


REQUIRED_SOURCE = [
    "README.md",
    "environment.yml",
    "configs/base.yaml",
    "configs/para.yaml",
    "configs/flickr_aes.yaml",
    "configs/lapis.yaml",
    "prism/models/prism.py",
    "prism/acquisition.py",
    "prism/calibration.py",
    "scripts/train_ensemble.py",
    "scripts/infer.py",
    "scripts/evaluate.py",
    "scripts/run_fixed_query.py",
    "scripts/run_concept_audit.py",
    "reference_outputs/manuscript_targets.json",
]


def require_source(root: Path) -> list[str]:
    return [relative for relative in REQUIRED_SOURCE if not (root / relative).exists()]


def require_empirical_runs(root: Path) -> list[str]:
    missing = []
    protocols = {"para": (5,), "flickr_aes": (1,), "lapis": (4,)}
    for dataset, (folds,) in protocols.items():
        for fold in range(folds):
            base = root / "runs" / dataset / "primary" / f"fold_{fold}"
            for name in ("calibration.json", "predictions.csv", "metrics/metrics.json"):
                if not (base / name).exists():
                    missing.append(str((base / name).relative_to(root)))
            for member_index, seed in enumerate(SEEDS, start=1):
                member = base / "checkpoints" / f"member_{member_index}_seed_{seed}"
                for name in ("provenance.json", "adapter_state.pt", "cohort_bank.pt"):
                    if not (member / name).exists():
                        missing.append(str((member / name).relative_to(root)))
                    elif name == "provenance.json":
                        payload = json.loads((member / name).read_text(encoding="utf-8"))
                        if payload.get("evidence_status") != "empirical":
                            missing.append(str((member / name).relative_to(root)) + ":non-empirical")
    return missing


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path("."))
    parser.add_argument("--require-empirical", action="store_true")
    args = parser.parse_args()
    root = args.root.resolve()
    failures = []
    failures.extend(f"missing:{value}" for value in require_source(root))
    failures.extend(f"scan:{value}" for value in scan(root))
    if args.require_empirical:
        failures.extend(f"empirical:{value}" for value in require_empirical_runs(root))
    if failures:
        raise SystemExit("Release gate failed:\n" + "\n".join(failures))
    print("release_structure=PASS")
    print(f"empirical_gate={'ENABLED' if args.require_empirical else 'NOT_REQUESTED'}")


if __name__ == "__main__":
    main()

