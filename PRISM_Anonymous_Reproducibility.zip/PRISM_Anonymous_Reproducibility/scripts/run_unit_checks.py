#!/usr/bin/env python3
"""Execute dependency-light unit checks in deterministic order."""

from __future__ import annotations

import importlib
import inspect


MODULES = [
    "tests.test_acquisition",
    "tests.test_calibration",
    "tests.test_metrics",
    "tests.test_splits",
    "tests.test_statistics",
    "tests.test_provenance",
]


def main() -> None:
    count = 0
    for module_name in MODULES:
        module = importlib.import_module(module_name)
        for name, function in sorted(inspect.getmembers(module, inspect.isfunction)):
            if name.startswith("test_"):
                function()
                count += 1
                print(f"{module_name}.{name}=PASS")
    print(f"unit_checks={count}")


if __name__ == "__main__":
    main()

