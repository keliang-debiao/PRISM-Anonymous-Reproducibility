#!/usr/bin/env python3
"""Create deterministic training, calibration, and test episode shards."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
import torch

from prism.config import load_config
from prism.constants import CONCEPTS
from prism.data.schema import normalize_rating


def load_features(feature_root: Path, image_id: str) -> list[torch.Tensor]:
    path = feature_root / f"{image_id}.npz"
    if not path.exists():
        raise FileNotFoundError(path)
    with np.load(path) as archive:
        levels = [torch.from_numpy(archive[f"layer_{index}"].astype(np.float32)) for index in range(4)]
    return levels


def profile_matrix(users: pd.DataFrame) -> tuple[dict[str, torch.Tensor], list[str]]:
    frame = users.copy()
    frame["user_id"] = frame["user_id"].astype(str)
    values = frame.drop(columns=["user_id", "official_partition"], errors="ignore")
    values = pd.get_dummies(values, dummy_na=False, dtype=float)
    missing = values.isna().astype(float).add_suffix("__missing")
    values = values.apply(lambda column: column.fillna(column.median() if column.notna().any() else 0.0))
    values = pd.concat([values, missing], axis=1).astype(float)
    mean = values.mean(axis=0)
    deviation = values.std(axis=0).replace(0.0, 1.0)
    values = (values - mean) / deviation
    mapping = {
        user_id: torch.tensor(values.iloc[index].to_numpy(np.float32))
        for index, user_id in enumerate(frame["user_id"])
    }
    return mapping, list(values.columns)


def concept_targets(images: pd.DataFrame, mapping_path: Path | None) -> dict[str, tuple[torch.Tensor, torch.Tensor]]:
    images = images.copy()
    images["image_id"] = images["image_id"].astype(str)
    mapping = {}
    if mapping_path and mapping_path.exists():
        payload = json.loads(mapping_path.read_text(encoding="utf-8"))
        if all(key in CONCEPTS for key in payload):
            mapping = payload
        else:
            for source, concept in payload.items():
                mapping.setdefault(concept, []).append(source)
    standardized = {}
    for columns in mapping.values():
        for column in columns:
            if column in images and column not in standardized:
                values = pd.to_numeric(images[column], errors="coerce")
                scale = values.std()
                standardized[column] = (values - values.mean()) / (scale if scale and np.isfinite(scale) else 1.0)
    result = {}
    for row_index, image_id in enumerate(images["image_id"]):
        target = np.zeros(16, dtype=np.float32)
        mask = np.zeros(16, dtype=np.float32)
        for concept_index, concept in enumerate(CONCEPTS):
            values = [standardized[column].iloc[row_index] for column in mapping.get(concept, []) if column in standardized]
            values = [float(value) for value in values if np.isfinite(value)]
            if values:
                target[concept_index] = float(np.mean(values))
                mask[concept_index] = 1.0
        result[image_id] = (torch.from_numpy(target), torch.from_numpy(mask))
    return result


def bootstrap_cohort_bank(
    interactions: pd.DataFrame,
    user_ids: list[str],
    dataset: str,
    hidden_dim: int,
) -> tuple[torch.Tensor, torch.Tensor]:
    rows = []
    for user in user_ids:
        values = normalize_rating(
            interactions.loc[interactions["user_id"] == user, "rating"].to_numpy(dtype=float),
            dataset,
        )
        histogram = np.histogram(values, bins=np.linspace(0.0, 1.0, 6))[0].astype(float)
        histogram /= max(1.0, histogram.sum())
        rows.append(
            np.concatenate(
                [
                    [values.mean(), values.std(), np.median(values), np.quantile(values, 0.25), np.quantile(values, 0.75)],
                    histogram,
                ]
            )
        )
    statistics = np.asarray(rows, dtype=np.float32)
    rng = np.random.default_rng(2026)
    projection = rng.normal(0.0, 1.0 / np.sqrt(statistics.shape[1]), (statistics.shape[1], hidden_dim))
    sensitivity_projection = rng.normal(0.0, 1.0 / np.sqrt(statistics.shape[1]), (statistics.shape[1], 16))
    preference = statistics @ projection
    preference /= np.maximum(np.linalg.norm(preference, axis=1, keepdims=True), 1e-8)
    sensitivity = np.tanh(statistics @ sensitivity_projection)
    return torch.tensor(preference, dtype=torch.float32), torch.tensor(sensitivity, dtype=torch.float32)


def choose_support(rows: pd.DataFrame, budget: int, seed: int) -> tuple[pd.DataFrame, pd.DataFrame]:
    ordered = rows.sort_values("image_id").copy()
    if budget == 0:
        return ordered.iloc[:0], ordered
    if len(ordered) <= budget:
        raise ValueError("A user has insufficient interactions for the requested support budget")
    rng = np.random.default_rng(seed)
    positions = np.sort(rng.choice(len(ordered), size=budget, replace=False))
    support = ordered.iloc[positions]
    query = ordered.drop(index=support.index)
    return support, query


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True, type=Path)
    parser.add_argument("--prepared-root", type=Path, default=Path("prepared_data"))
    parser.add_argument("--feature-root", type=Path, default=Path("feature_cache"))
    parser.add_argument("--split-manifest", required=True, type=Path)
    parser.add_argument("--fold", required=True, type=int)
    parser.add_argument("--support-budget", required=True, type=int)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--source-concepts", type=Path)
    args = parser.parse_args()
    config = load_config(args.config)
    dataset = config["dataset"]["name"]
    root = args.prepared_root / dataset
    interactions = pd.read_csv(root / "interactions.csv", dtype={"user_id": str, "image_id": str})
    users = pd.read_csv(root / "users.csv", dtype={"user_id": str})
    images = pd.read_csv(root / "images.csv", dtype={"image_id": str})
    split = pd.read_csv(args.split_manifest, dtype={"user_id": str, "image_id": str})
    split = split[split["fold"] == args.fold]
    frame = interactions.merge(
        split[["user_id", "image_id", "partition"]],
        on=["user_id", "image_id"],
        how="inner",
        validate="one_to_one",
    )
    profiles, profile_columns = profile_matrix(users)
    targets = concept_targets(images, root / "attribute_map.json")
    training_users = sorted(frame.loc[frame["partition"] == "train", "user_id"].unique())
    user_index = {user: index for index, user in enumerate(training_users)}
    cohort_preference, cohort_sensitivity = bootstrap_cohort_bank(
        frame[frame["partition"] == "train"], training_users, dataset, config["model"]["hidden_dim"]
    )
    source_concepts = None
    if config["domain_alignment"]["enabled"]:
        if args.source_concepts is None:
            raise ValueError("LAPIS episode construction requires frozen PARA shared concepts")
        source_concepts = np.load(args.source_concepts)["concepts"].astype(np.float32)
    args.output.mkdir(parents=True, exist_ok=True)
    torch.save(
        {"preference": cohort_preference, "sensitivity": cohort_sensitivity, "user_ids": training_users},
        args.output / "cohort_bank.pt",
    )
    (args.output / "profile_schema.json").write_text(
        json.dumps({"columns": profile_columns}, indent=2), encoding="utf-8"
    )
    counters = {"train": 0, "selection": 0, "calibration": 0, "test": 0}
    feature_root = args.feature_root / dataset
    for partition, partition_frame in frame.groupby("partition", sort=True):
        for user, user_rows in partition_frame.groupby("user_id", sort=True):
            support, query = choose_support(
                user_rows,
                args.support_budget,
                2026 + args.fold + sum(ord(character) for character in user),
            )
            support_levels = [load_features(feature_root, image_id) for image_id in support["image_id"]]
            if support_levels:
                stacked_support = [
                    torch.stack([record[level] for record in support_levels]) for level in range(4)
                ]
            else:
                first_query = load_features(feature_root, str(query.iloc[0]["image_id"]))
                stacked_support = [level.new_empty((0, *level.shape)) for level in first_query]
            support_ratings = torch.tensor(
                normalize_rating(support["rating"].to_numpy(dtype=float), dataset), dtype=torch.float32
            )
            for query_row in query.itertuples(index=False):
                visual_levels = load_features(feature_root, str(query_row.image_id))
                attribute_target, attribute_mask = targets.get(
                    str(query_row.image_id),
                    (torch.zeros(16), torch.zeros(16)),
                )
                normalized = float(normalize_rating(np.asarray([query_row.rating]), dataset)[0])
                record = {
                    "user_id": str(user),
                    "image_id": str(query_row.image_id),
                    "user_index": user_index.get(str(user), -1),
                    "profile": profiles[str(user)],
                    "visual_levels": visual_levels,
                    "support_visual_levels": stacked_support,
                    "support_ratings_normalized": support_ratings,
                    "observed": torch.tensor(float(query_row.rating), dtype=torch.float32),
                    "ordinal_label": torch.tensor(min(4, int(normalized * 5)), dtype=torch.long),
                    "attribute_targets": attribute_target,
                    "attribute_mask": attribute_mask,
                }
                if source_concepts is not None:
                    source_index = counters[partition] % len(source_concepts)
                    record["source_shared_concepts"] = torch.tensor(
                        source_concepts[source_index, :10], dtype=torch.float32
                    )
                target_name = "train" if partition == "train" else partition
                torch.save(record, args.output / f"{target_name}_{counters[partition]:08d}.pt")
                counters[partition] += 1
    (args.output / "shard_manifest.json").write_text(
        json.dumps(
            {
                "dataset": dataset,
                "fold": args.fold,
                "support_budget": args.support_budget,
                "counts": counters,
                "profile_dim": len(profile_columns),
                "cohort_users": len(training_users),
            },
            indent=2,
        ),
        encoding="utf-8",
    )


if __name__ == "__main__":
    main()

