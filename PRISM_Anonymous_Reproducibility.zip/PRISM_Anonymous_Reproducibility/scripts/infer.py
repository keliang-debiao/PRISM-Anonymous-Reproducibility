#!/usr/bin/env python3
"""Run five-member inference and write row-level calibrated predictions."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import torch
from torch.utils.data import DataLoader

from prism.calibration import calibrated_probabilities, prediction_intervals
from prism.config import load_config
from prism.data.torch_dataset import EpisodeShardDataset, collate_episode_records
from prism.engine import write_prediction_rows
from prism.models.prism import PRISMEnsemble
from scripts.train_ensemble import build_member, move


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True, type=Path)
    parser.add_argument("--shards", required=True, type=Path)
    parser.add_argument("--checkpoint-root", required=True, type=Path)
    parser.add_argument("--calibration", type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--visual-dim", required=True, type=int)
    parser.add_argument("--profile-dim", required=True, type=int)
    parser.add_argument("--fold", required=True, type=int)
    parser.add_argument("--support-budget", required=True, type=int)
    parser.add_argument("--split", choices=["calibration", "test"], default="test")
    args = parser.parse_args()
    config = load_config(args.config)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    members = []
    learned_banks = []
    for index, seed in enumerate(config["reproducibility"]["seeds"], start=1):
        member = build_member(config, args.visual_dim, args.profile_dim)
        state_path = args.checkpoint_root / f"member_{index}_seed_{seed}" / "adapter_state.pt"
        member.load_state_dict(torch.load(state_path, map_location="cpu", weights_only=True))
        members.append(member)
        bank_path = args.checkpoint_root / f"member_{index}_seed_{seed}" / "cohort_bank.pt"
        if bank_path.exists():
            learned_banks.append(torch.load(bank_path, map_location="cpu", weights_only=True))
    model = PRISMEnsemble(members).to(device).eval()
    calibration = {"temperature": 1.0, "variance_multiplier": 1.0}
    if args.calibration:
        calibration = json.loads(args.calibration.read_text(encoding="utf-8"))
    dataset = EpisodeShardDataset(args.shards, args.split)
    if learned_banks:
        cohort_preference = torch.stack([bank["preference"] for bank in learned_banks]).mean(dim=0).to(device)
        cohort_sensitivity = torch.stack([bank["sensitivity"] for bank in learned_banks]).mean(dim=0).to(device)
    else:
        cohort_preference = dataset.cohort_preference.to(device)
        cohort_sensitivity = dataset.cohort_sensitivity.to(device)
    loader = DataLoader(dataset, batch_size=1, shuffle=False, collate_fn=collate_episode_records)
    score_min = config["dataset"]["score_min"]
    score_max = config["dataset"]["score_max"]
    rows = []
    with torch.no_grad():
        for batch in loader:
            batch = {key: move(value, device) for key, value in batch.items()}
            output = model(
                visual_levels=batch["visual_levels"],
                support_tokens=None,
                support_visual_levels=batch["support_visual_levels"],
                support_ratings_normalized=batch["support_ratings_normalized"],
                profile=batch["profile"],
                cohort_preference=cohort_preference,
                cohort_sensitivity=cohort_sensitivity,
            )
            mean = output["mean"].detach().cpu().numpy()
            variance = output["total_variance"].detach().cpu().numpy()
            logits = output["ordinal_logits"].detach().cpu().numpy()
            probabilities = calibrated_probabilities(logits, calibration["temperature"])
            first_member = model.members[0]
            mapping = lambda values: first_member.scale_mapping(
                torch.as_tensor(values, device=device, dtype=torch.float32)
            ).detach().cpu().numpy()
            latent = output["member_latent_scores"].mean(dim=0).detach().cpu().numpy()
            intervals = prediction_intervals(
                latent,
                variance,
                calibration["variance_multiplier"],
                mapping,
                score_min,
                score_max,
            )
            rows.append(
                {
                    "dataset": config["dataset"]["name"],
                    "fold": args.fold,
                    "seed": "ensemble_2026_2030",
                    "user_id": batch["user_id"][0],
                    "image_id": batch["image_id"][0],
                    "support_budget": args.support_budget,
                    "partition": args.split,
                    "observed": float(batch["observed"].detach().cpu().item()),
                    "predicted": float(mean[0]),
                    "latent_mean": float(latent[0]),
                    "total_variance": float(variance[0]),
                    "interval_lower_raw": float(intervals["lower_raw"][0]),
                    "interval_upper_raw": float(intervals["upper_raw"][0]),
                    "interval_lower_bounded": float(intervals["lower_bounded"][0]),
                    "interval_upper_bounded": float(intervals["upper_bounded"][0]),
                    "ordinal_label": int(batch["ordinal_label"].detach().cpu().item()),
                    "ordinal_probabilities": probabilities[0].tolist(),
                    "concept_activations": output["concepts"][0].detach().cpu().tolist(),
                    "concept_sensitivities": output["concept_sensitivities"][0].detach().cpu().tolist(),
                    "routing_weights": output["routing_weights"][0].detach().cpu().tolist(),
                    "evidence_status": "empirical",
                }
            )
    write_prediction_rows(args.output, rows)


if __name__ == "__main__":
    main()

