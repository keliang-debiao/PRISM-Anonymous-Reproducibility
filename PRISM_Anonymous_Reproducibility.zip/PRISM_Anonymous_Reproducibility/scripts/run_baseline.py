#!/usr/bin/env python3
"""Run a controlled baseline through a common prediction contract."""

from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd

from prism.baselines import (
    load_entrypoint,
    load_registry,
    validate_baseline_predictions,
)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--name", required=True)
    parser.add_argument("--module", required=True, type=Path)
    parser.add_argument("--config", required=True, type=Path)
    parser.add_argument("--split-manifest", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--support-budget", type=int, default=10)
    args = parser.parse_args()
    registry = load_registry()
    if args.name not in registry:
        raise KeyError(f"Unregistered baseline: {args.name}")
    entrypoint = load_entrypoint(args.module)
    frame = entrypoint(
        baseline_name=args.name,
        baseline_settings=registry[args.name],
        config_path=args.config,
        split_manifest=args.split_manifest,
        support_budget=args.support_budget,
    )
    if not isinstance(frame, pd.DataFrame):
        raise TypeError("Baseline entry point must return a pandas DataFrame")
    validate_baseline_predictions(frame)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    frame.to_csv(args.output, index=False)


if __name__ == "__main__":
    main()

