#!/usr/bin/env python3
"""Fit ordinal temperature and continuous variance multiplier on calibration users."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd

from prism.calibration import fit_temperature, fit_variance_multiplier
from prism.utils.reproducibility import write_json_atomic


def unpack_vector(column: pd.Series) -> np.ndarray:
    return np.asarray([json.loads(value) for value in column], dtype=float)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--predictions", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    frame = pd.read_csv(args.predictions)
    if "partition" in frame and not (frame["partition"] == "calibration").all():
        raise ValueError("Calibration input contains non-calibration users")
    temperature = fit_temperature(unpack_vector(frame["ordinal_logits"]), frame["ordinal_label"].to_numpy())
    multiplier = fit_variance_multiplier(
        frame["observed"].to_numpy(), frame["predicted"].to_numpy(), frame["total_variance"].to_numpy()
    )
    write_json_atomic(
        args.output,
        {"temperature": temperature, "variance_multiplier": multiplier, "fitted_on": "calibration_users"},
    )


if __name__ == "__main__":
    main()

