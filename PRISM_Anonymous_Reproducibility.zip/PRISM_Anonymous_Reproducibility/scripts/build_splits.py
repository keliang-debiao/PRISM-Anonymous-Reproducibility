#!/usr/bin/env python3
"""Create deterministic user, image, strict, and fixed-query manifests."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd

from prism.data.splits import (
    assign_duplicate_groups_to_folds,
    balanced_user_folds,
    fixed_query_assignment,
    split_manifest_hash,
)


def split_selection_and_calibration(users: list[str], fold: int) -> dict[str, str]:
    rng = np.random.default_rng(2026 + fold)
    users = np.asarray(sorted(users), dtype=object)
    rng.shuffle(users)
    assignment = {str(user): "train" for user in users}
    for user in users[-64:-32]:
        assignment[str(user)] = "selection"
    for user in users[-32:]:
        assignment[str(user)] = "calibration"
    return assignment


def build_para(root: Path, output: Path) -> None:
    interactions = pd.read_csv(root / "interactions.csv", dtype={"user_id": str, "image_id": str})
    images = pd.read_csv(root / "images.csv", dtype={"image_id": str})
    development = interactions[interactions["official_partition"] == "development"].copy()
    official_test = interactions[interactions["official_partition"] == "test"].copy()
    if development["user_id"].nunique() != 398 or official_test["user_id"].nunique() != 40:
        raise ValueError("PARA official membership does not match 398 development and 40 test users")
    user_folds = balanced_user_folds(development["user_id"], [80, 80, 80, 79, 79])
    records = []
    for fold in range(5):
        heldout = {user for user, assigned in user_folds.items() if assigned == fold}
        remaining = sorted(set(user_folds) - heldout)
        role = split_selection_and_calibration(remaining, fold)
        block = development[["user_id", "image_id"]].copy()
        block["fold"] = fold
        block["partition"] = block["user_id"].map(
            lambda user: "test" if user in heldout else role[str(user)]
        )
        records.append(block)
    manifest = pd.concat(records, ignore_index=True)
    manifest["protocol"] = "user_disjoint"
    manifest["seed"] = 2026
    manifest["manifest_hash"] = split_manifest_hash(manifest)
    manifest.to_csv(output / "para_user_disjoint.csv", index=False)

    fixed = fixed_query_assignment(development)
    fixed["manifest_hash"] = split_manifest_hash(fixed)
    fixed.to_csv(output / "para_fixed_query.csv", index=False)

    if "duplicate_group" not in images:
        images["duplicate_group"] = images["image_id"]
    images["strict_image_fold"] = assign_duplicate_groups_to_folds(images, 5)
    strict = development.merge(
        images[["image_id", "duplicate_group", "strict_image_fold"]],
        on="image_id",
        how="left",
        validate="many_to_one",
    )
    strict["strict_user_fold"] = strict["user_id"].map(user_folds)
    strict["manifest_hash"] = split_manifest_hash(strict)
    strict.to_csv(output / "para_strict.csv", index=False)

    official_test.assign(protocol="official_test", seed=2026).to_csv(
        output / "para_official_test.csv", index=False
    )


def build_flickr(root: Path, output: Path) -> None:
    frame = pd.read_csv(root / "interactions.csv", dtype={"user_id": str, "image_id": str})
    counts = frame.groupby("official_partition")["user_id"].nunique().to_dict()
    if counts.get("train") != 173 or counts.get("test") != 37:
        raise ValueError("FLICKR-AES official membership does not match 173 training and 37 test users")
    training_users = np.asarray(
        sorted(frame.loc[frame["official_partition"] == "train", "user_id"].unique()),
        dtype=object,
    )
    rng = np.random.default_rng(2026)
    rng.shuffle(training_users)
    calibration_users = set(training_users[-17:])
    selection_users = set(training_users[-34:-17])
    frame["fold"] = 0
    frame["partition"] = frame.apply(
        lambda row: (
            "test"
            if row["official_partition"] == "test"
            else "calibration"
            if row["user_id"] in calibration_users
            else "selection"
            if row["user_id"] in selection_users
            else "train"
        ),
        axis=1,
    )
    frame["protocol"] = "official"
    frame["seed"] = 2026
    frame["manifest_hash"] = split_manifest_hash(frame)
    frame.to_csv(output / "flickr_aes_official.csv", index=False)


def build_lapis(root: Path, output: Path) -> None:
    frame = pd.read_csv(root / "interactions.csv", dtype={"user_id": str, "image_id": str})
    users = sorted(frame["user_id"].unique())
    if len(users) != 552:
        raise ValueError("LAPIS requires 552 users")
    folds = balanced_user_folds(users, [138, 138, 138, 138])
    records = []
    for fold in range(4):
        heldout = {user for user, assigned in folds.items() if assigned == fold}
        remaining = np.asarray(sorted(set(users) - heldout), dtype=object)
        rng = np.random.default_rng(2026 + fold)
        rng.shuffle(remaining)
        calibration_users = set(remaining[-41:])
        selection_users = set(remaining[-82:-41])
        block = frame[["user_id", "image_id"]].copy()
        block["fold"] = fold
        block["partition"] = block["user_id"].map(
            lambda user: (
                "test"
                if user in heldout
                else "calibration"
                if user in calibration_users
                else "selection"
                if user in selection_users
                else "train"
            )
        )
        records.append(block)
    manifest = pd.concat(records, ignore_index=True)
    manifest["protocol"] = "user_disjoint"
    manifest["seed"] = 2026
    manifest["manifest_hash"] = split_manifest_hash(manifest)
    manifest.to_csv(output / "lapis_user_disjoint.csv", index=False)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset", choices=["para", "flickr_aes", "lapis"])
    parser.add_argument("--all", action="store_true")
    parser.add_argument("--prepared-root", type=Path, default=Path("prepared_data"))
    parser.add_argument("--output", type=Path, default=Path("splits/generated"))
    args = parser.parse_args()
    datasets = ["para", "flickr_aes", "lapis"] if args.all else [args.dataset]
    if datasets == [None]:
        parser.error("Select --dataset or --all")
    args.output.mkdir(parents=True, exist_ok=True)
    builders = {"para": build_para, "flickr_aes": build_flickr, "lapis": build_lapis}
    for dataset in datasets:
        builders[dataset](args.prepared_root / dataset, args.output)


if __name__ == "__main__":
    main()

