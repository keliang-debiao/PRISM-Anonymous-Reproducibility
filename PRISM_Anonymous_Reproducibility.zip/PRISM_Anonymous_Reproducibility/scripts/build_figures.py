#!/usr/bin/env python3
"""Generate numerical result figures from empirical CSV artifacts."""

from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd

from prism.provenance import require_empirical


def line_figure(frame: pd.DataFrame, x: str, y: str, group: str, path: Path, ylabel: str) -> None:
    figure, axis = plt.subplots(figsize=(7.2, 4.2), dpi=200)
    for name, block in frame.groupby(group, sort=True):
        ordered = block.sort_values(x)
        axis.plot(ordered[x], ordered[y], marker="o", linewidth=1.8, label=str(name))
    axis.set_xlabel(x.replace("_", " ").title())
    axis.set_ylabel(ylabel)
    axis.grid(alpha=0.25)
    axis.legend(frameon=False)
    figure.tight_layout()
    figure.savefig(path, dpi=300, bbox_inches="tight")
    plt.close(figure)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--runs", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    require_empirical(sorted(args.runs.glob("**/provenance.json")))
    args.output.mkdir(parents=True, exist_ok=True)
    fixed = args.runs / "fixed_query" / "fixed_query_metrics.csv"
    if fixed.exists():
        frame = pd.read_csv(fixed)
        line_figure(frame, "budget", "srocc", "policy", args.output / "figure_fixed_query.png", "SROCC")
    support = args.runs / "support_budget_metrics.csv"
    if support.exists():
        frame = pd.read_csv(support)
        line_figure(frame, "support_budget", "srocc", "dataset", args.output / "figure_support_budget.png", "SROCC")


if __name__ == "__main__":
    main()

