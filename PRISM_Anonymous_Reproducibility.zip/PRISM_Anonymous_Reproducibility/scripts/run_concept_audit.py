#!/usr/bin/env python3
"""Compute prespecified per-concept correlations and deletion sensitivity."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd

from prism.audit import concept_attribute_correlations, deletion_effect, select_case_strata
from prism.constants import CONCEPTS


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--predictions", required=True, type=Path)
    parser.add_argument("--attributes", required=True, type=Path)
    parser.add_argument("--mapping", required=True, type=Path)
    parser.add_argument("--deletions", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    predictions = pd.read_csv(args.predictions, dtype={"image_id": str})
    attributes = pd.read_csv(args.attributes, dtype={"image_id": str})
    merged = predictions.merge(attributes, on="image_id", how="inner", validate="many_to_one")
    concepts = np.asarray([json.loads(value) for value in merged["concept_activations"]])
    mapping_by_name = json.loads(args.mapping.read_text(encoding="utf-8"))
    mapping = {CONCEPTS.index(name): columns for name, columns in mapping_by_name.items() if name in CONCEPTS}
    correlations = concept_attribute_correlations(concepts, merged, mapping)
    correlations["concept"] = correlations["concept_index"].map(lambda index: CONCEPTS[index])
    deletions = pd.read_csv(args.deletions)
    summary = {
        "top_three_deletion": deletion_effect(deletions["original"], deletions["top_three_deleted"]),
        "random_three_deletion": deletion_effect(deletions["original"], deletions["random_three_deleted"]),
    }
    case_frame = predictions.copy()
    case_frame["interval_width"] = (
        case_frame["interval_upper_bounded"] - case_frame["interval_lower_bounded"]
    )
    cases = select_case_strata(case_frame)
    args.output.mkdir(parents=True, exist_ok=True)
    correlations.to_csv(args.output / "per_concept_correlations.csv", index=False)
    cases.to_csv(args.output / "case_audit.csv", index=False)
    (args.output / "deletion_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()

