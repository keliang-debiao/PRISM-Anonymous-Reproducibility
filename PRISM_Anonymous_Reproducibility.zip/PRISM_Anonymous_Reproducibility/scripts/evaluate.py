#!/usr/bin/env python3
"""Calculate per-user metrics, calibration, intervals, and paired inference."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd

from prism.metrics import (
    aggregate_user_metrics,
    brier_score,
    expected_calibration_error,
    interval_metrics,
    per_user_metrics,
)
from prism.statistics import bca_cluster_interval, paired_wilcoxon
from prism.utils.reproducibility import write_json_atomic


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--predictions", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--compare")
    args = parser.parse_args()
    frame = pd.read_csv(args.predictions)
    users = per_user_metrics(frame)
    summary = aggregate_user_metrics(users)
    summary["srocc_ci"] = bca_cluster_interval(users["srocc"].to_numpy())
    if "ordinal_probabilities" in frame:
        probabilities = np.asarray([json.loads(value) for value in frame["ordinal_probabilities"]])
        labels = frame["ordinal_label"].to_numpy(dtype=int)
        summary["ece"] = expected_calibration_error(probabilities, labels)
        summary["brier"] = brier_score(probabilities, labels)
    if {"interval_lower_bounded", "interval_upper_bounded"} <= set(frame.columns):
        summary.update(
            interval_metrics(
                frame["observed"].to_numpy(),
                frame["interval_lower_bounded"].to_numpy(),
                frame["interval_upper_bounded"].to_numpy(),
            )
        )
    args.output.mkdir(parents=True, exist_ok=True)
    users.to_csv(args.output / "user_metrics.csv", index=False)
    if args.compare:
        comparison = pd.read_csv(args.compare)
        comparison_users = per_user_metrics(comparison)
        paired = users.merge(comparison_users, on="user_id", suffixes=("_first", "_second"))
        summary["paired_srocc"] = paired_wilcoxon(
            paired["srocc_first"].to_numpy(), paired["srocc_second"].to_numpy()
        )
    write_json_atomic(args.output / "metrics.json", summary)


if __name__ == "__main__":
    main()

