# PRISM Anonymous Reproducibility Repository

This repository implements the computational workflow described in
**Preference Efficient Personalized Image Aesthetic Assessment with Calibrated Cohort Mixtures**.
It is organized for anonymous peer review and contains data validation, split
construction, feature extraction, model training, calibration, acquisition,
inference, statistical analysis, table generation, figure generation, and
integrity checks.

## Evidence boundary

The public datasets and pretrained Qwen3-VL weights are not redistributed.
Files under `reference_outputs/` are manuscript-reported targets transcribed
from the submitted paper. They are comparison targets, not newly measured
results. Files under `logs/` record package-integrity and compact CPU workflow
checks on generated validation records. They are not results from PARA,
FLICKR-AES, or LAPIS and must not be cited as empirical evidence.

For a reviewer-facing release, place the authors' real fold predictions,
checkpoints, calibration files, and timing records in the locations documented
in `docs/REVIEWER_GUIDE.md`, then run the integrity and target-verification
commands below. The scripts reject provenance records marked as non-empirical
when manuscript-result tables are requested.

## Repository map

| Path | Purpose |
| --- | --- |
| `configs/` | Model, dataset, optimization, split, calibration, and ablation settings |
| `prism/` | Data, model, acquisition, loss, calibration, evaluation, and audit code |
| `scripts/` | Command-line entry points for each stage of the workflow |
| `schemas/` | Required columns and prediction-file contracts |
| `splits/` | Deterministic protocol specification and generated split manifests |
| `reference_outputs/` | Manuscript-reported targets and extracted paper tables |
| `tests/` | Deterministic unit and integration checks |
| `logs/` | Package-check records with explicit evidence status |

## Environment

The full model requires Linux, Python 3.11, CUDA 12.1 or later, and two GPUs
with at least 24 GB memory each. The manuscript configuration used two NVIDIA
RTX 4090 GPUs. A CPU-only environment is sufficient for split, metric,
calibration, statistical, provenance, and package-integrity checks.

```bash
conda env create -f environment.yml
conda activate prism
python -m pip install -e .
```

The backbone identifier defaults to `Qwen/Qwen3-VL-4B-Instruct`. Access to the
model weights must follow the provider's license and authentication rules.

## Data preparation

Arrange each public dataset according to `docs/DATA_LAYOUT.md`, then run:

```bash
python scripts/prepare_dataset.py --dataset para --root /path/to/PARA
python scripts/prepare_dataset.py --dataset flickr_aes --root /path/to/FLICKR_AES
python scripts/prepare_dataset.py --dataset lapis --root /path/to/LAPIS
python scripts/build_splits.py --all
```

The split builder creates:

- five user-disjoint PARA folds with development sizes 80, 80, 80, 79, and 79;
- the frozen PARA official-test partition;
- simultaneous user-and-image-disjoint sensitivity folds;
- the official 173-user and 37-user FLICKR-AES split;
- four user-disjoint LAPIS folds;
- deterministic 70% acquisition and 30% fixed-query partitions;
- SHA-256 and near-duplicate group constraints.

## Main reproduction commands

```bash
bash run_reproduction.sh para
bash run_reproduction.sh flickr_aes
bash run_reproduction.sh lapis
python scripts/run_fixed_query.py --config configs/para.yaml
python scripts/run_ablation.py --config configs/para.yaml
python scripts/run_concept_audit.py --config configs/para.yaml
python scripts/run_efficiency.py --config configs/para.yaml
python scripts/build_tables.py --runs runs --output artifacts/tables
python scripts/build_figures.py --runs runs --output artifacts/figures
python scripts/verify_targets.py --runs runs --targets reference_outputs/manuscript_targets.json
```

Five independent members are trained with seeds 2026-2030. Each member receives
its own initialization and optimizer state. Calibration is fitted only on the
designated calibration users after training and before test evaluation.

`scripts/reproduce.py` is the fold-wise orchestrator used by
`run_reproduction.sh`. It creates episode shards, trains the five members,
fits calibration on calibration users, produces row-level test predictions,
and calculates user-level and aggregate metrics.

## Compact package check

```bash
bash validate_package.sh
```

This command checks source syntax, configuration consistency, split isolation,
fixed-query stability, interval clipping, metric calculations, provenance
gating, anonymous metadata, and prohibited-text constraints.

## Expected empirical artifacts

The complete reviewer release should contain, for every dataset and fold:

1. immutable split manifests with content hashes;
2. five member checkpoints or adapter states;
3. calibration parameters fitted on calibration users;
4. row-level query predictions with user and image identifiers;
5. acquisition traces for every support budget and policy;
6. per-user metrics and paired-comparison inputs;
7. environment, hardware, seed, commit, and command metadata;
8. generated tables and figures linked to their source prediction files.

`scripts/check_release.py` fails if any required empirical artifact is absent or
if a result file has an incompatible provenance status.

