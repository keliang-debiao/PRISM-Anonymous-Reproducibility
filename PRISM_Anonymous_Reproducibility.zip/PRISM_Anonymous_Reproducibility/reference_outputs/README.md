# Manuscript targets

The files in this directory contain values reported in the submitted
manuscript. They support automated consistency checks between empirical runs
and the paper. They are not generated measurements and are never loaded by the
training or inference code.

`verify_targets.py` compares independently produced empirical artifacts with
these values using explicit tolerances. It does not alter or backfill run
outputs.

