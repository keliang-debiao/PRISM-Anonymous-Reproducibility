#!/usr/bin/env bash
set -euo pipefail

dataset_name="${1:?dataset required: para, flickr_aes, or lapis}"
case "$dataset_name" in
  para|flickr_aes|lapis) ;;
  *) echo "unsupported dataset: $dataset_name" >&2; exit 2 ;;
esac

data_root="${PRISM_DATA_ROOT:?set PRISM_DATA_ROOT to the public dataset parent directory}"
image_root="${PRISM_IMAGE_ROOT:?set PRISM_IMAGE_ROOT to the dataset image directory}"
run_root="${PRISM_RUN_ROOT:-runs}"
config_path="configs/${dataset_name}.yaml"

python scripts/prepare_dataset.py \
  --dataset "$dataset_name" \
  --root "$data_root/$dataset_name"

python scripts/build_splits.py --dataset "$dataset_name"

python scripts/extract_features.py \
  --dataset "$dataset_name" \
  --image-root "$image_root"

case "$dataset_name" in
  para) split_manifest="splits/generated/para_user_disjoint.csv" ;;
  flickr_aes) split_manifest="splits/generated/flickr_aes_official.csv" ;;
  lapis) split_manifest="splits/generated/lapis_user_disjoint.csv" ;;
esac

reproduce_args=(
  --config "$config_path"
  --split-manifest "$split_manifest"
  --run-root "$run_root"
  --support-budget 10
)

if [[ "$dataset_name" == "lapis" ]]; then
  source_concepts="${PRISM_PARA_SHARED_CONCEPTS:?set PRISM_PARA_SHARED_CONCEPTS for LAPIS adaptation}"
  reproduce_args+=(--source-concepts "$source_concepts")
fi

python scripts/reproduce.py "${reproduce_args[@]}"

